import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertTournamentSchema, insertTeamSchema, insertUserSchema, insertRegistrationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket setup for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  
  const clients = new Set<WebSocket>();
  
  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected');
    
    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected');
    });
  });

  // Broadcast function for real-time updates
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // User routes
  app.post("/api/users", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(userData);
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  app.get("/api/users/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user", error });
    }
  });

  app.get("/api/leaderboard/global", async (req, res) => {
    try {
      const topPlayers = await storage.getTopPlayers(10);
      res.json(topPlayers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leaderboard", error });
    }
  });

  // Tournament routes
  app.post("/api/tournaments", async (req, res) => {
    try {
      const tournamentData = insertTournamentSchema.parse(req.body);
      const tournament = await storage.createTournament(tournamentData);
      
      // Broadcast new tournament to all connected clients
      broadcast({
        type: 'tournament_created',
        data: tournament
      });
      
      res.json(tournament);
    } catch (error) {
      res.status(400).json({ message: "Invalid tournament data", error });
    }
  });

  app.get("/api/tournaments", async (req, res) => {
    try {
      const status = req.query.status as string;
      const tournaments = await storage.getTournaments(status);
      res.json(tournaments);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tournaments", error });
    }
  });

  app.get("/api/tournaments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const tournament = await storage.getTournament(id);
      if (!tournament) {
        return res.status(404).json({ message: "Tournament not found" });
      }
      res.json(tournament);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tournament", error });
    }
  });

  app.put("/api/tournaments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const tournament = await storage.updateTournament(id, updates);
      
      // Broadcast tournament update
      broadcast({
        type: 'tournament_updated',
        data: tournament
      });
      
      res.json(tournament);
    } catch (error) {
      res.status(500).json({ message: "Failed to update tournament", error });
    }
  });

  app.delete("/api/tournaments/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTournament(id);
      
      broadcast({
        type: 'tournament_deleted',
        data: { id }
      });
      
      res.json({ message: "Tournament deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete tournament", error });
    }
  });

  // Tournament registration routes
  app.post("/api/tournaments/:id/register", async (req, res) => {
    try {
      const tournamentId = parseInt(req.params.id);
      const registrationData = insertRegistrationSchema.parse({
        ...req.body,
        tournamentId
      });
      
      const registration = await storage.registerForTournament(registrationData);
      
      // Broadcast registration update
      broadcast({
        type: 'tournament_registration',
        data: { tournamentId, registration }
      });
      
      res.json(registration);
    } catch (error) {
      res.status(400).json({ message: "Registration failed", error });
    }
  });

  app.get("/api/tournaments/:id/registrations", async (req, res) => {
    try {
      const tournamentId = parseInt(req.params.id);
      const registrations = await storage.getTournamentRegistrations(tournamentId);
      res.json(registrations);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch registrations", error });
    }
  });

  app.put("/api/registrations/:id/payment", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, paymentId } = req.body;
      await storage.updateRegistrationPaymentStatus(id, status, paymentId);
      res.json({ message: "Payment status updated" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update payment status", error });
    }
  });

  // Team routes
  app.post("/api/teams", async (req, res) => {
    try {
      const teamData = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(teamData);
      res.json(team);
    } catch (error) {
      res.status(400).json({ message: "Invalid team data", error });
    }
  });

  app.get("/api/teams/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const team = await storage.getTeam(id);
      if (!team) {
        return res.status(404).json({ message: "Team not found" });
      }
      res.json(team);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch team", error });
    }
  });

  app.get("/api/teams/:id/members", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const members = await storage.getTeamMembers(id);
      res.json(members);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch team members", error });
    }
  });

  app.post("/api/teams/:id/members", async (req, res) => {
    try {
      const teamId = parseInt(req.params.id);
      const { userId, role } = req.body;
      await storage.addTeamMember(teamId, userId, role);
      res.json({ message: "Member added successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to add team member", error });
    }
  });

  app.delete("/api/teams/:teamId/members/:userId", async (req, res) => {
    try {
      const teamId = parseInt(req.params.teamId);
      const userId = parseInt(req.params.userId);
      await storage.removeTeamMember(teamId, userId);
      res.json({ message: "Member removed successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to remove team member", error });
    }
  });

  app.get("/api/users/:id/teams", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const teams = await storage.getTeamsByUser(userId);
      res.json(teams);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user teams", error });
    }
  });

  // Match routes
  app.get("/api/tournaments/:id/matches", async (req, res) => {
    try {
      const tournamentId = parseInt(req.params.id);
      const matches = await storage.getMatches(tournamentId);
      res.json(matches);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch matches", error });
    }
  });

  app.put("/api/matches/:id/result", async (req, res) => {
    try {
      const matchId = parseInt(req.params.id);
      const { winnerId, winnerType } = req.body;
      await storage.updateMatchResult(matchId, winnerId, winnerType);
      
      broadcast({
        type: 'match_result',
        data: { matchId, winnerId, winnerType }
      });
      
      res.json({ message: "Match result updated" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update match result", error });
    }
  });

  // Leaderboard routes
  app.get("/api/tournaments/:id/leaderboard", async (req, res) => {
    try {
      const tournamentId = parseInt(req.params.id);
      const leaderboard = await storage.getLeaderboard(tournamentId);
      res.json(leaderboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch leaderboard", error });
    }
  });

  app.put("/api/tournaments/:id/leaderboard", async (req, res) => {
    try {
      const tournamentId = parseInt(req.params.id);
      const { userId, kills, points } = req.body;
      await storage.updateLeaderboard(tournamentId, userId, kills, points);
      
      const updatedLeaderboard = await storage.getLeaderboard(tournamentId);
      broadcast({
        type: 'leaderboard_updated',
        data: { tournamentId, leaderboard: updatedLeaderboard }
      });
      
      res.json({ message: "Leaderboard updated" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update leaderboard", error });
    }
  });

  // Notification routes
  app.post("/api/notifications", async (req, res) => {
    try {
      const notificationData = req.body;
      const notification = await storage.createNotification(notificationData);
      
      broadcast({
        type: 'notification',
        data: notification
      });
      
      res.json(notification);
    } catch (error) {
      res.status(400).json({ message: "Failed to create notification", error });
    }
  });

  app.get("/api/users/:id/notifications", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const notifications = await storage.getUserNotifications(userId);
      res.json(notifications);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notifications", error });
    }
  });

  app.put("/api/notifications/:id/read", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.markNotificationRead(id);
      res.json({ message: "Notification marked as read" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update notification", error });
    }
  });

  // Payment routes (Razorpay integration)
  app.post("/api/payments/create-order", async (req, res) => {
    try {
      const { amount, currency = "INR", receipt } = req.body;
      
      // This would integrate with Razorpay SDK
      const order = {
        id: `order_${Date.now()}`,
        amount: amount * 100, // Convert to paise
        currency,
        receipt,
        status: "created"
      };
      
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to create payment order", error });
    }
  });

  app.post("/api/payments/verify", async (req, res) => {
    try {
      const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
      
      // This would verify payment with Razorpay
      // For now, we'll simulate successful payment
      const isValid = true;
      
      if (isValid) {
        res.json({ status: "success", payment_id: razorpay_payment_id });
      } else {
        res.status(400).json({ message: "Payment verification failed" });
      }
    } catch (error) {
      res.status(500).json({ message: "Payment verification failed", error });
    }
  });

  return httpServer;
}
