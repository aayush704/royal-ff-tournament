import {
  users,
  tournaments,
  teams,
  teamMembers,
  tournamentRegistrations,
  matches,
  matchParticipants,
  leaderboard,
  notifications,
  type User,
  type InsertUser,
  type Tournament,
  type InsertTournament,
  type Team,
  type InsertTeam,
  type TournamentRegistration,
  type InsertTournamentRegistration,
  type Match,
  type MatchParticipant,
  type LeaderboardEntry,
  type Notification,
  type InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, or, count, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<InsertUser>): Promise<User>;
  getTopPlayers(limit?: number): Promise<User[]>;

  // Tournament operations
  createTournament(tournament: InsertTournament): Promise<Tournament>;
  getTournament(id: number): Promise<Tournament | undefined>;
  getTournaments(status?: string): Promise<Tournament[]>;
  updateTournament(id: number, updates: Partial<InsertTournament>): Promise<Tournament>;
  deleteTournament(id: number): Promise<void>;
  getTournamentsByUser(userId: number): Promise<Tournament[]>;

  // Team operations
  createTeam(team: InsertTeam): Promise<Team>;
  getTeam(id: number): Promise<Team | undefined>;
  getTeamsByUser(userId: number): Promise<Team[]>;
  updateTeam(id: number, updates: Partial<InsertTeam>): Promise<Team>;
  deleteTeam(id: number): Promise<void>;
  addTeamMember(teamId: number, userId: number, role?: string): Promise<void>;
  removeTeamMember(teamId: number, userId: number): Promise<void>;
  getTeamMembers(teamId: number): Promise<User[]>;

  // Registration operations
  registerForTournament(registration: InsertTournamentRegistration): Promise<TournamentRegistration>;
  getTournamentRegistrations(tournamentId: number): Promise<TournamentRegistration[]>;
  getUserRegistrations(userId: number): Promise<TournamentRegistration[]>;
  updateRegistrationPaymentStatus(id: number, status: string, paymentId?: string): Promise<void>;

  // Match operations
  createMatch(match: Omit<Match, 'id' | 'createdAt'>): Promise<Match>;
  getMatches(tournamentId: number): Promise<Match[]>;
  updateMatchResult(matchId: number, winnerId: number, winnerType: string): Promise<void>;

  // Leaderboard operations
  getLeaderboard(tournamentId: number): Promise<LeaderboardEntry[]>;
  updateLeaderboard(tournamentId: number, userId: number, kills: number, points: number): Promise<void>;

  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getUserNotifications(userId: number): Promise<Notification[]>;
  markNotificationRead(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<InsertUser>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getTopPlayers(limit = 10): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .orderBy(desc(users.totalKills), desc(users.totalWins))
      .limit(limit);
  }

  // Tournament operations
  async createTournament(tournament: InsertTournament): Promise<Tournament> {
    const [newTournament] = await db.insert(tournaments).values(tournament).returning();
    return newTournament;
  }

  async getTournament(id: number): Promise<Tournament | undefined> {
    const [tournament] = await db.select().from(tournaments).where(eq(tournaments.id, id));
    return tournament;
  }

  async getTournaments(status?: string): Promise<Tournament[]> {
    if (status) {
      return await db
        .select()
        .from(tournaments)
        .where(eq(tournaments.status, status))
        .orderBy(desc(tournaments.startTime));
    }
    return await db.select().from(tournaments).orderBy(desc(tournaments.startTime));
  }

  async updateTournament(id: number, updates: Partial<InsertTournament>): Promise<Tournament> {
    const [tournament] = await db
      .update(tournaments)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(tournaments.id, id))
      .returning();
    return tournament;
  }

  async deleteTournament(id: number): Promise<void> {
    await db.delete(tournaments).where(eq(tournaments.id, id));
  }

  async getTournamentsByUser(userId: number): Promise<Tournament[]> {
    return await db
      .select()
      .from(tournaments)
      .where(eq(tournaments.createdBy, userId))
      .orderBy(desc(tournaments.createdAt));
  }

  // Team operations
  async createTeam(team: InsertTeam): Promise<Team> {
    const [newTeam] = await db.insert(teams).values(team).returning();
    
    // Add captain as first member
    await db.insert(teamMembers).values({
      teamId: newTeam.id,
      userId: team.captainId,
      role: "captain",
    });

    return newTeam;
  }

  async getTeam(id: number): Promise<Team | undefined> {
    const [team] = await db.select().from(teams).where(eq(teams.id, id));
    return team;
  }

  async getTeamsByUser(userId: number): Promise<Team[]> {
    return await db
      .select({ 
        id: teams.id,
        name: teams.name,
        logoUrl: teams.logoUrl,
        captainId: teams.captainId,
        maxMembers: teams.maxMembers,
        currentMembers: teams.currentMembers,
        createdAt: teams.createdAt,
        updatedAt: teams.updatedAt,
      })
      .from(teams)
      .innerJoin(teamMembers, eq(teams.id, teamMembers.teamId))
      .where(eq(teamMembers.userId, userId));
  }

  async updateTeam(id: number, updates: Partial<InsertTeam>): Promise<Team> {
    const [team] = await db
      .update(teams)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(teams.id, id))
      .returning();
    return team;
  }

  async deleteTeam(id: number): Promise<void> {
    await db.delete(teamMembers).where(eq(teamMembers.teamId, id));
    await db.delete(teams).where(eq(teams.id, id));
  }

  async addTeamMember(teamId: number, userId: number, role = "member"): Promise<void> {
    await db.insert(teamMembers).values({
      teamId,
      userId,
      role,
    });

    // Update current members count
    const [memberCount] = await db
      .select({ count: count() })
      .from(teamMembers)
      .where(eq(teamMembers.teamId, teamId));

    await db
      .update(teams)
      .set({ currentMembers: memberCount.count })
      .where(eq(teams.id, teamId));
  }

  async removeTeamMember(teamId: number, userId: number): Promise<void> {
    await db
      .delete(teamMembers)
      .where(and(eq(teamMembers.teamId, teamId), eq(teamMembers.userId, userId)));

    // Update current members count
    const [memberCount] = await db
      .select({ count: count() })
      .from(teamMembers)
      .where(eq(teamMembers.teamId, teamId));

    await db
      .update(teams)
      .set({ currentMembers: memberCount.count })
      .where(eq(teams.id, teamId));
  }

  async getTeamMembers(teamId: number): Promise<User[]> {
    return await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        firstName: users.firstName,
        lastName: users.lastName,
        profileImageUrl: users.profileImageUrl,
        gameUid: users.gameUid,
        coins: users.coins,
        totalKills: users.totalKills,
        totalWins: users.totalWins,
        totalEarnings: users.totalEarnings,
        isAdmin: users.isAdmin,
        password: users.password,
        createdAt: users.createdAt,
        updatedAt: users.updatedAt,
      })
      .from(users)
      .innerJoin(teamMembers, eq(users.id, teamMembers.userId))
      .where(eq(teamMembers.teamId, teamId));
  }

  // Registration operations
  async registerForTournament(registration: InsertTournamentRegistration): Promise<TournamentRegistration> {
    const [newRegistration] = await db.insert(tournamentRegistrations).values(registration).returning();
    
    // Update tournament current players count
    await db
      .update(tournaments)
      .set({ 
        currentPlayers: sql`${tournaments.currentPlayers} + 1`
      })
      .where(eq(tournaments.id, registration.tournamentId));

    return newRegistration;
  }

  async getTournamentRegistrations(tournamentId: number): Promise<TournamentRegistration[]> {
    return await db
      .select()
      .from(tournamentRegistrations)
      .where(eq(tournamentRegistrations.tournamentId, tournamentId));
  }

  async getUserRegistrations(userId: number): Promise<TournamentRegistration[]> {
    return await db
      .select()
      .from(tournamentRegistrations)
      .where(eq(tournamentRegistrations.userId, userId))
      .orderBy(desc(tournamentRegistrations.registeredAt));
  }

  async updateRegistrationPaymentStatus(id: number, status: string, paymentId?: string): Promise<void> {
    await db
      .update(tournamentRegistrations)
      .set({ paymentStatus: status, paymentId })
      .where(eq(tournamentRegistrations.id, id));
  }

  // Match operations
  async createMatch(match: Omit<Match, 'id' | 'createdAt'>): Promise<Match> {
    const [newMatch] = await db.insert(matches).values(match).returning();
    return newMatch;
  }

  async getMatches(tournamentId: number): Promise<Match[]> {
    return await db
      .select()
      .from(matches)
      .where(eq(matches.tournamentId, tournamentId))
      .orderBy(matches.round, matches.matchNumber);
  }

  async updateMatchResult(matchId: number, winnerId: number, winnerType: string): Promise<void> {
    await db
      .update(matches)
      .set({ 
        winnerId, 
        winnerType, 
        status: "completed",
        endTime: new Date() 
      })
      .where(eq(matches.id, matchId));
  }

  // Leaderboard operations
  async getLeaderboard(tournamentId: number): Promise<LeaderboardEntry[]> {
    return await db
      .select()
      .from(leaderboard)
      .where(eq(leaderboard.tournamentId, tournamentId))
      .orderBy(desc(leaderboard.totalPoints), desc(leaderboard.totalKills));
  }

  async updateLeaderboard(tournamentId: number, userId: number, kills: number, points: number): Promise<void> {
    const existing = await db
      .select()
      .from(leaderboard)
      .where(and(eq(leaderboard.tournamentId, tournamentId), eq(leaderboard.userId, userId)));

    if (existing.length > 0) {
      await db
        .update(leaderboard)
        .set({
          totalKills: sql`${leaderboard.totalKills} + ${kills}`,
          totalPoints: sql`${leaderboard.totalPoints} + ${points}`,
          updatedAt: new Date(),
        })
        .where(and(eq(leaderboard.tournamentId, tournamentId), eq(leaderboard.userId, userId)));
    } else {
      await db.insert(leaderboard).values({
        tournamentId,
        userId,
        totalKills: kills,
        totalPoints: points,
      });
    }
  }

  // Notification operations
  async createNotification(notification: InsertNotification): Promise<Notification> {
    const [newNotification] = await db.insert(notifications).values(notification).returning();
    return newNotification;
  }

  async getUserNotifications(userId: number): Promise<Notification[]> {
    return await db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt))
      .limit(50);
  }

  async markNotificationRead(id: number): Promise<void> {
    await db
      .update(notifications)
      .set({ isRead: true })
      .where(eq(notifications.id, id));
  }
}

export const storage = new DatabaseStorage();
