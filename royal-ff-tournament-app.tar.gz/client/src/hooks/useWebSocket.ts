import { useEffect, useRef, useState } from 'react';
import { useToast } from '@/hooks/use-toast';

interface WebSocketMessage {
  type: string;
  data: any;
}

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const ws = useRef<WebSocket | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    ws.current = new WebSocket(wsUrl);

    ws.current.onopen = () => {
      setIsConnected(true);
      console.log('WebSocket connected');
    };

    ws.current.onclose = () => {
      setIsConnected(false);
      console.log('WebSocket disconnected');
    };

    ws.current.onmessage = (event) => {
      try {
        const message: WebSocketMessage = JSON.parse(event.data);
        handleWebSocketMessage(message);
      } catch (error) {
        console.error('Failed to parse WebSocket message:', error);
      }
    };

    ws.current.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    return () => {
      if (ws.current) {
        ws.current.close();
      }
    };
  }, []);

  const handleWebSocketMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'tournament_created':
        toast({
          title: "New Tournament!",
          description: `${message.data.name} has been created`,
        });
        break;
      case 'tournament_updated':
        toast({
          title: "Tournament Updated",
          description: `${message.data.name} has been updated`,
        });
        break;
      case 'tournament_registration':
        toast({
          title: "New Registration",
          description: "A player has registered for the tournament",
        });
        break;
      case 'match_result':
        toast({
          title: "Match Result",
          description: "A match has been completed",
        });
        break;
      case 'leaderboard_updated':
        // Handle leaderboard updates silently or with subtle notification
        break;
      case 'notification':
        toast({
          title: message.data.title,
          description: message.data.message,
        });
        break;
      default:
        console.log('Unhandled WebSocket message:', message);
    }
  };

  const sendMessage = (message: WebSocketMessage) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify(message));
    }
  };

  return { isConnected, sendMessage };
}
