export const TOURNAMENT_TYPES = {
  SOLO: 'solo',
  DUO: 'duo',
  SQUAD: 'squad'
} as const;

export const GAME_MODES = {
  BR: 'br',
  CLASH_SQUAD: 'clash_squad'
} as const;

export const TOURNAMENT_STATUS = {
  UPCOMING: 'upcoming',
  LIVE: 'live',
  COMPLETED: 'completed',
  CANCELLED: 'cancelled'
} as const;

export const PAYMENT_STATUS = {
  PENDING: 'pending',
  COMPLETED: 'completed',
  FAILED: 'failed'
} as const;

export const MATCH_STATUS = {
  SCHEDULED: 'scheduled',
  LIVE: 'live',
  COMPLETED: 'completed'
} as const;

export const NOTIFICATION_TYPES = {
  TOURNAMENT: 'tournament',
  PAYMENT: 'payment',
  TEAM: 'team',
  SYSTEM: 'system'
} as const;

export const DEMO_USER = {
  id: 1,
  username: 'JohnDoe',
  email: 'john@example.com',
  firstName: 'John',
  lastName: 'Doe',
  gameUid: '123456789',
  coins: 1250,
  totalKills: 458,
  totalWins: 12,
  totalEarnings: '8500',
  profileImageUrl: null,
  isAdmin: true
};
