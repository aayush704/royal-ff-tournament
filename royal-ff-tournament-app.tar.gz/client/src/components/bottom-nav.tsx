import { Link, useLocation } from "wouter";
import { Home, Trophy, Users, User } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function BottomNav() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Home", icon: Home },
    { path: "/tournaments", label: "Tournaments", icon: Trophy },
    { path: "/teams", label: "Teams", icon: Users },
    { path: "/profile", label: "Profile", icon: User },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-ff-card border-t md:hidden z-40" style={{ borderColor: 'rgba(66, 153, 255, 0.3)' }}>
      <div className="flex items-center justify-around py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;
          
          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                size="sm" 
                className={`flex flex-col items-center py-2 px-4 ${
                  isActive ? "" : "text-gray-400 hover:text-white"
                }`}
                style={isActive ? { color: 'var(--ff-blue)' } : {}}
              >
                <Icon className="h-5 w-5 mb-1" />
                <span className="text-xs">{item.label}</span>
              </Button>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
