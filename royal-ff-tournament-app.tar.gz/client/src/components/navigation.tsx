import { Link, useLocation } from "wouter";
import { DEMO_USER } from "@/lib/constants";
import { Coins, Crown, Menu, Settings } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export default function Navigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  const navItems = [
    { path: "/", label: "Home", icon: "🏠" },
    { path: "/tournaments", label: "Tournaments", icon: "🏆" },
    { path: "/teams", label: "Teams", icon: "👥" },
    { path: "/profile", label: "Profile", icon: "👤" },
  ];

  if (DEMO_USER.isAdmin) {
    navItems.push({ path: "/admin", label: "Admin", icon: "⚙️" });
  }

  return (
    <header className="bg-ff-card border-b sticky top-0 z-50" style={{ borderColor: 'rgba(66, 153, 255, 0.3)' }}>
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: 'linear-gradient(to right, var(--ff-blue), var(--ff-orange))' }}>
              <Crown className="text-white text-xl" />
            </div>
            <h1 className="text-xl font-bold text-white">Royal FF Tournament</h1>
          </Link>
          
          <div className="flex items-center space-x-4">
            {/* Coins Display */}
            <div className="hidden md:flex items-center space-x-2 bg-ff-dark px-3 py-1 rounded-full">
              <Coins className="text-ff-gold text-sm" />
              <span className="text-sm font-semibold">{DEMO_USER.coins.toLocaleString()}</span>
            </div>
            
            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center space-x-6">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={location === item.path ? "default" : "ghost"}
                    className={location === item.path ? "text-white" : "text-gray-300 hover:text-white"}
                    style={location === item.path ? { backgroundColor: 'var(--ff-blue)' } : {}}
                  >
                    <span className="mr-2">{item.icon}</span>
                    {item.label}
                  </Button>
                </Link>
              ))}
            </nav>
            
            {/* User Profile */}
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 rounded-full flex items-center justify-center" style={{ background: 'linear-gradient(to right, var(--ff-blue), var(--ff-red))' }}>
                <span className="text-xs font-bold">
                  {DEMO_USER.firstName?.[0]}{DEMO_USER.lastName?.[0]}
                </span>
              </div>
              <div className="hidden md:block">
                <p className="text-sm font-semibold">{DEMO_USER.firstName} {DEMO_USER.lastName}</p>
                <p className="text-xs text-gray-400">UID: {DEMO_USER.gameUid}</p>
              </div>
            </div>
            
            {/* Mobile Menu */}
            <Sheet open={isOpen} onOpenChange={setIsOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon" className="md:hidden">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="bg-ff-card" style={{ borderColor: 'rgba(66, 153, 255, 0.3)' }}>
                <div className="flex flex-col space-y-4 mt-8">
                  {navItems.map((item) => (
                    <Link key={item.path} href={item.path} onClick={() => setIsOpen(false)}>
                      <Button
                        variant={location === item.path ? "default" : "ghost"}
                        className={`w-full justify-start ${
                          location === item.path ? "text-white" : "text-gray-300 hover:text-white"
                        }`}
                        style={location === item.path ? { backgroundColor: 'var(--ff-blue)' } : {}}
                      >
                        <span className="mr-2">{item.icon}</span>
                        {item.label}
                      </Button>
                    </Link>
                  ))}
                  
                  <div className="pt-4 border-t" style={{ borderColor: 'rgba(66, 153, 255, 0.3)' }}>
                    <div className="flex items-center space-x-2 bg-ff-dark px-3 py-2 rounded-full">
                      <Coins className="text-ff-gold text-sm" />
                      <span className="text-sm font-semibold">{DEMO_USER.coins.toLocaleString()} Coins</span>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
