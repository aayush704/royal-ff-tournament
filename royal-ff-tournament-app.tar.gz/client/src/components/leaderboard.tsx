import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Target, Medal, Crown } from "lucide-react";
import { User } from "@shared/schema";

interface LeaderboardEntry extends User {
  position?: number;
  totalPoints?: number;
}

interface LeaderboardProps {
  players: LeaderboardEntry[];
  title?: string;
  showPoints?: boolean;
}

export default function Leaderboard({ players, title = "Leaderboard", showPoints = false }: LeaderboardProps) {
  const getRankIcon = (position: number) => {
    switch (position) {
      case 1:
        return <Crown className="text-ff-gold h-5 w-5" />;
      case 2:
        return <Medal className="text-gray-400 h-5 w-5" />;
      case 3:
        return <Medal className="text-orange-600 h-5 w-5" />;
      default:
        return null;
    }
  };

  const getRankBadge = (position: number) => {
    switch (position) {
      case 1:
        return "bg-ff-gold text-black";
      case 2:
        return "bg-gray-400 text-black";
      case 3:
        return "bg-orange-600 text-white";
      default:
        return "bg-ff-card text-white";
    }
  };

  return (
    <Card className="gaming-card">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Trophy className="text-ff-gold h-5 w-5" />
          <span>{title}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {players.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <Trophy className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No players yet</p>
            </div>
          ) : (
            players.map((player, index) => {
              const position = player.position || index + 1;
              
              return (
                <div 
                  key={player.id} 
                  className="flex items-center justify-between p-3 bg-ff-dark/30 rounded-lg hover:bg-ff-dark/50 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center space-x-2">
                      <Badge className={`w-8 h-8 rounded-full flex items-center justify-center p-0 ${getRankBadge(position)}`}>
                        <span className="text-xs font-bold">{position}</span>
                      </Badge>
                      {getRankIcon(position)}
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-ff-orange to-ff-red rounded-full flex items-center justify-center">
                        <span className="text-xs font-bold">
                          {player.firstName?.[0] || player.username[0]}
                          {player.lastName?.[0] || player.username[1] || ''}
                        </span>
                      </div>
                      
                      <div>
                        <p className="font-semibold">
                          {player.firstName && player.lastName 
                            ? `${player.firstName} ${player.lastName}` 
                            : player.username
                          }
                        </p>
                        <p className="text-xs text-gray-400">UID: {player.gameUid || 'N/A'}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 text-sm">
                    <div className="flex items-center space-x-1">
                      <Target className="text-ff-red h-4 w-4" />
                      <span className="font-semibold text-ff-red">{player.totalKills}</span>
                    </div>
                    
                    <div className="flex items-center space-x-1">
                      <Trophy className="text-ff-success h-4 w-4" />
                      <span className="font-semibold text-ff-success">{player.totalWins}</span>
                    </div>
                    
                    {showPoints && player.totalPoints !== undefined && (
                      <div className="font-bold text-ff-gold">{player.totalPoints} pts</div>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>
      </CardContent>
    </Card>
  );
}
