import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, Clock, Trophy, DollarSign } from "lucide-react";
import CountdownTimer from "./countdown-timer";
import { Tournament } from "@shared/schema";
import { Link } from "wouter";

interface TournamentCardProps {
  tournament: Tournament;
  onRegister?: (tournamentId: number) => void;
}

export default function TournamentCard({ tournament, onRegister }: TournamentCardProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live':
        return 'status-live';
      case 'upcoming':
        return 'status-upcoming';
      case 'completed':
        return 'status-completed';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'live':
        return 'LIVE';
      case 'upcoming':
        return 'UPCOMING';
      case 'completed':
        return 'COMPLETED';
      default:
        return status.toUpperCase();
    }
  };

  const isFull = tournament.currentPlayers >= tournament.maxPlayers;
  const canRegister = tournament.status === 'upcoming' && !isFull;

  return (
    <Card className={`gaming-card hover:scale-105 transition-transform cursor-pointer ${
      tournament.status === 'live' ? 'tournament-active' : ''
    }`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <Badge className={`${getStatusColor(tournament.status)} text-xs font-bold`}>
            {getStatusText(tournament.status)}
          </Badge>
          <div className="flex items-center space-x-1 text-ff-gold font-bold">
            <DollarSign className="h-4 w-4" />
            <span>₹{tournament.entryFee} Entry</span>
          </div>
        </div>
        
        <Link href={`/tournaments/${tournament.id}`}>
          <h4 className="text-lg font-bold mb-2 hover:text-ff-orange transition-colors">
            {tournament.name}
          </h4>
        </Link>
        
        <p className="text-sm text-gray-400 mb-4 line-clamp-2">
          {tournament.description || `${tournament.tournamentType.toUpperCase()} ${tournament.gameMode.toUpperCase()} matches`}
        </p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Users className="text-ff-blue h-4 w-4" />
            <span className="text-sm">
              {tournament.currentPlayers}/{tournament.maxPlayers} Players
            </span>
          </div>
          
          {tournament.status === 'upcoming' && (
            <CountdownTimer 
              targetDate={new Date(tournament.startTime)} 
              className="text-sm"
            />
          )}
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-gray-400">Prize Pool</p>
            <div className="flex items-center space-x-1">
              <Trophy className="text-ff-gold h-4 w-4" />
              <p className="text-lg font-bold text-ff-gold">₹{tournament.prizePool}</p>
            </div>
          </div>
          
          {canRegister && onRegister && (
            <Button 
              className="btn-success"
              onClick={(e) => {
                e.preventDefault();
                onRegister(tournament.id);
              }}
              disabled={isFull}
            >
              {isFull ? 'Full' : 'Register'}
            </Button>
          )}
          
          {tournament.status === 'live' && (
            <Button className="btn-primary">
              Join Now
            </Button>
          )}
          
          {tournament.entryFee === '0' && (
            <Button className="btn-secondary">
              Join Free
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
