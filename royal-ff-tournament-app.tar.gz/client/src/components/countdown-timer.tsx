import { useState, useEffect } from "react";
import { Clock } from "lucide-react";

interface CountdownTimerProps {
  targetDate: Date;
  onComplete?: () => void;
  className?: string;
}

export default function CountdownTimer({ targetDate, onComplete, className = "" }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date().getTime();
      const target = new Date(targetDate).getTime();
      const difference = target - now;

      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)),
          minutes: Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60)),
          seconds: Math.floor((difference % (1000 * 60)) / 1000)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        if (onComplete) {
          onComplete();
        }
      }
    }, 1000);

    return () => clearInterval(timer);
  }, [targetDate, onComplete]);

  const formatTime = (time: number) => time.toString().padStart(2, '0');

  if (timeLeft.days === 0 && timeLeft.hours === 0 && timeLeft.minutes === 0 && timeLeft.seconds === 0) {
    return (
      <div className={`flex items-center space-x-2 ${className}`}>
        <Clock className="text-ff-red h-4 w-4" />
        <span className="text-sm font-semibold text-ff-red">Started</span>
      </div>
    );
  }

  return (
    <div className={`flex items-center space-x-2 ${className}`}>
      <Clock className="text-ff-orange h-4 w-4" />
      <div className="flex items-center space-x-1 text-sm font-mono">
        {timeLeft.days > 0 && (
          <>
            <span className="font-semibold">{timeLeft.days}d</span>
            <span className="text-gray-400">:</span>
          </>
        )}
        <span className="font-semibold">{formatTime(timeLeft.hours)}</span>
        <span className="text-gray-400">:</span>
        <span className="font-semibold">{formatTime(timeLeft.minutes)}</span>
        <span className="text-gray-400">:</span>
        <span className="font-semibold">{formatTime(timeLeft.seconds)}</span>
      </div>
    </div>
  );
}
