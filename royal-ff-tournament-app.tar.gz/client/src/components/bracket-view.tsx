import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Trophy, Users, Clock } from "lucide-react";
import { Match } from "@shared/schema";

interface BracketViewProps {
  matches: Match[];
  tournamentId: number;
  onUpdateResult?: (matchId: number, winnerId: number) => void;
}

export default function BracketView({ matches, onUpdateResult }: BracketViewProps) {
  const groupedMatches = matches.reduce((acc, match) => {
    if (!acc[match.round]) {
      acc[match.round] = [];
    }
    acc[match.round].push(match);
    return acc;
  }, {} as Record<number, Match[]>);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live':
        return 'bg-ff-success text-black';
      case 'completed':
        return 'bg-ff-gold text-black';
      case 'scheduled':
        return 'bg-ff-blue text-white';
      default:
        return 'bg-gray-500 text-white';
    }
  };

  const getRoundName = (round: number, totalRounds: number) => {
    const roundsFromEnd = totalRounds - round + 1;
    switch (roundsFromEnd) {
      case 1:
        return 'Final';
      case 2:
        return 'Semi-Final';
      case 3:
        return 'Quarter-Final';
      default:
        return `Round ${round}`;
    }
  };

  const maxRound = Math.max(...Object.keys(groupedMatches).map(Number));

  if (matches.length === 0) {
    return (
      <Card className="gaming-card">
        <CardContent className="p-8 text-center">
          <Trophy className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-400">Tournament bracket will be generated when registration closes</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-8">
      {Object.entries(groupedMatches)
        .sort(([a], [b]) => Number(a) - Number(b))
        .map(([round, roundMatches]) => (
          <Card key={round} className="gaming-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="text-ff-gold h-5 w-5" />
                <span>{getRoundName(Number(round), maxRound)}</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {roundMatches.map((match) => (
                  <Card key={match.id} className="bg-ff-dark/50 border border-ff-orange/30">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-3">
                        <Badge className={`text-xs font-bold ${getStatusColor(match.status)}`}>
                          {match.status.toUpperCase()}
                        </Badge>
                        <span className="text-sm text-gray-400">Match #{match.matchNumber}</span>
                      </div>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center justify-between p-2 bg-ff-card rounded border-l-4 border-ff-blue">
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4 text-ff-blue" />
                            <span className="font-semibold">Team A</span>
                          </div>
                          {match.winnerId && match.winnerType === 'team' && (
                            <Trophy className="h-4 w-4 text-ff-gold" />
                          )}
                        </div>
                        
                        <div className="text-center text-xs text-gray-400 font-bold">VS</div>
                        
                        <div className="flex items-center justify-between p-2 bg-ff-card rounded border-l-4 border-ff-red">
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4 text-ff-red" />
                            <span className="font-semibold">Team B</span>
                          </div>
                          {match.winnerId && match.winnerType === 'team' && (
                            <Trophy className="h-4 w-4 text-ff-gold" />
                          )}
                        </div>
                      </div>
                      
                      {match.startTime && (
                        <div className="flex items-center justify-center space-x-2 mb-3 text-sm text-gray-400">
                          <Clock className="h-4 w-4" />
                          <span>{new Date(match.startTime).toLocaleDateString()}</span>
                          <span>{new Date(match.startTime).toLocaleTimeString()}</span>
                        </div>
                      )}
                      
                      {match.roomId && (
                        <div className="text-center p-2 bg-ff-dark rounded text-sm">
                          <p className="text-gray-400">Room ID</p>
                          <p className="font-mono font-bold text-ff-orange">{match.roomId}</p>
                          {match.roomPassword && (
                            <>
                              <p className="text-gray-400 mt-1">Password</p>
                              <p className="font-mono font-bold text-ff-blue">{match.roomPassword}</p>
                            </>
                          )}
                        </div>
                      )}
                      
                      {match.status === 'live' && onUpdateResult && (
                        <div className="mt-3 space-y-2">
                          <Button 
                            size="sm" 
                            className="w-full btn-primary"
                            onClick={() => onUpdateResult(match.id, 1)} // Team A wins
                          >
                            Team A Wins
                          </Button>
                          <Button 
                            size="sm" 
                            className="w-full btn-secondary"
                            onClick={() => onUpdateResult(match.id, 2)} // Team B wins
                          >
                            Team B Wins
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
    </div>
  );
}
