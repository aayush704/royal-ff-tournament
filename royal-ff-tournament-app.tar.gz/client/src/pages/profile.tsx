import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertUserSchema, Tournament, TournamentRegistration } from "@shared/schema";
import { DEMO_USER } from "@/lib/constants";
import { 
  User, 
  Trophy, 
  Target, 
  Medal, 
  DollarSign,
  Calendar,
  Settings,
  Edit,
  Camera,
  Coins,
  TrendingUp,
  History,
  Award
} from "lucide-react";
import { z } from "zod";

const updateProfileSchema = insertUserSchema.pick({
  firstName: true,
  lastName: true,
  gameUid: true,
}).extend({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  gameUid: z.string().min(1, "Game UID is required"),
});

type UpdateProfileForm = z.infer<typeof updateProfileSchema>;

export default function Profile() {
  const { toast } = useToast();
  const [isEditing, setIsEditing] = useState(false);

  const { data: user = DEMO_USER } = useQuery({
    queryKey: [`/api/users/${DEMO_USER.id}`],
  });

  const { data: userRegistrations = [] } = useQuery<TournamentRegistration[]>({
    queryKey: [`/api/users/${DEMO_USER.id}/registrations`],
  });

  const { data: userTournaments = [] } = useQuery<Tournament[]>({
    queryKey: [`/api/users/${DEMO_USER.id}/tournaments`],
  });

  const form = useForm<UpdateProfileForm>({
    resolver: zodResolver(updateProfileSchema),
    defaultValues: {
      firstName: user.firstName || "",
      lastName: user.lastName || "",
      gameUid: user.gameUid || "",
    },
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: UpdateProfileForm) => {
      await apiRequest('PUT', `/api/users/${DEMO_USER.id}`, data);
    },
    onSuccess: () => {
      toast({
        title: "Profile Updated!",
        description: "Your profile has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${DEMO_USER.id}`] });
      setIsEditing(false);
    },
    onError: (error) => {
      toast({
        title: "Failed to Update Profile",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onUpdateProfile = (data: UpdateProfileForm) => {
    updateProfileMutation.mutate(data);
  };

  const calculateWinRate = () => {
    const totalTournaments = userRegistrations.length;
    if (totalTournaments === 0) return 0;
    return Math.round((user.totalWins / totalTournaments) * 100);
  };

  const calculateAverageKills = () => {
    const totalTournaments = userRegistrations.length;
    if (totalTournaments === 0) return 0;
    return Math.round(user.totalKills / totalTournaments);
  };

  const getRankColor = (rank: number) => {
    if (rank <= 100) return "text-ff-gold";
    if (rank <= 500) return "text-gray-400";
    if (rank <= 1000) return "text-orange-600";
    return "text-gray-500";
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Profile Header */}
      <Card className="gaming-card">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-6">
            {/* Profile Picture */}
            <div className="relative">
              <div className="w-24 h-24 bg-gradient-to-r from-ff-orange to-ff-red rounded-full flex items-center justify-center text-2xl font-bold">
                {user.profileImageUrl ? (
                  <img 
                    src={user.profileImageUrl} 
                    alt="Profile" 
                    className="w-full h-full object-cover rounded-full"
                  />
                ) : (
                  <span>
                    {user.firstName?.[0] || user.username[0]}
                    {user.lastName?.[0] || user.username[1] || ''}
                  </span>
                )}
              </div>
              <Button 
                size="sm" 
                className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-ff-blue hover:bg-ff-orange"
              >
                <Camera className="h-4 w-4" />
              </Button>
            </div>
            
            {/* Profile Info */}
            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                  <h1 className="text-2xl font-bold">
                    {user.firstName && user.lastName 
                      ? `${user.firstName} ${user.lastName}` 
                      : user.username
                    }
                  </h1>
                  <p className="text-gray-400">UID: {user.gameUid || 'Not set'}</p>
                  <div className="flex items-center justify-center md:justify-start space-x-4 mt-2">
                    <Badge className="bg-ff-gold text-black">
                      Global Rank #{247}
                    </Badge>
                    <div className="flex items-center space-x-1">
                      <Coins className="text-ff-gold h-4 w-4" />
                      <span className="font-semibold">{user.coins?.toLocaleString()} Coins</span>
                    </div>
                  </div>
                </div>
                
                <Button 
                  onClick={() => setIsEditing(!isEditing)}
                  className="mt-4 md:mt-0 btn-primary"
                >
                  <Edit className="mr-2 h-4 w-4" />
                  {isEditing ? 'Cancel' : 'Edit Profile'}
                </Button>
              </div>
            </div>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="stats-card">
              <Trophy className="text-ff-gold text-2xl mb-2 mx-auto" />
              <p className="text-sm text-gray-400">Tournaments Won</p>
              <p className="text-xl font-bold">{user.totalWins}</p>
            </div>
            <div className="stats-card">
              <Target className="text-ff-red text-2xl mb-2 mx-auto" />
              <p className="text-sm text-gray-400">Total Kills</p>
              <p className="text-xl font-bold">{user.totalKills}</p>
            </div>
            <div className="stats-card">
              <TrendingUp className="text-ff-blue text-2xl mb-2 mx-auto" />
              <p className="text-sm text-gray-400">Win Rate</p>
              <p className="text-xl font-bold">{calculateWinRate()}%</p>
            </div>
            <div className="stats-card">
              <DollarSign className="text-ff-success text-2xl mb-2 mx-auto" />
              <p className="text-sm text-gray-400">Total Earnings</p>
              <p className="text-xl font-bold">₹{user.totalEarnings}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Edit Profile Form */}
      {isEditing && (
        <Card className="gaming-card">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="text-ff-orange h-5 w-5" />
              <span>Edit Profile</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={form.handleSubmit(onUpdateProfile)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name *</Label>
                  <Input
                    id="firstName"
                    className="input-gaming"
                    {...form.register('firstName')}
                  />
                  {form.formState.errors.firstName && (
                    <p className="text-red-500 text-sm">{form.formState.errors.firstName.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name *</Label>
                  <Input
                    id="lastName"
                    className="input-gaming"
                    {...form.register('lastName')}
                  />
                  {form.formState.errors.lastName && (
                    <p className="text-red-500 text-sm">{form.formState.errors.lastName.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="gameUid">Free Fire UID *</Label>
                <Input
                  id="gameUid"
                  placeholder="Your Free Fire UID"
                  className="input-gaming"
                  {...form.register('gameUid')}
                />
                {form.formState.errors.gameUid && (
                  <p className="text-red-500 text-sm">{form.formState.errors.gameUid.message}</p>
                )}
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsEditing(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="btn-success"
                  disabled={updateProfileMutation.isPending}
                >
                  {updateProfileMutation.isPending ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Tabs */}
      <Tabs defaultValue="overview">
        <TabsList className="bg-ff-card border border-ff-orange/30">
          <TabsTrigger value="overview" className="data-[state=active]:bg-ff-orange">
            Overview
          </TabsTrigger>
          <TabsTrigger value="tournaments" className="data-[state=active]:bg-ff-orange">
            Tournament History
          </TabsTrigger>
          <TabsTrigger value="achievements" className="data-[state=active]:bg-ff-orange">
            Achievements
          </TabsTrigger>
          <TabsTrigger value="statistics" className="data-[state=active]:bg-ff-orange">
            Statistics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Performance Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="gaming-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <TrendingUp className="text-ff-blue h-5 w-5" />
                  <span>Performance Metrics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Average Kills per Game:</span>
                  <span className="font-bold text-ff-red">{calculateAverageKills()}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Win Rate:</span>
                  <span className="font-bold text-ff-success">{calculateWinRate()}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Tournaments Played:</span>
                  <span className="font-bold">{userRegistrations.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Global Ranking:</span>
                  <span className={`font-bold ${getRankColor(247)}`}>#247</span>
                </div>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="text-ff-gold h-5 w-5" />
                  <span>Recent Achievements</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-2 bg-ff-dark/30 rounded">
                  <Trophy className="text-ff-gold h-6 w-6" />
                  <div>
                    <p className="font-semibold">Tournament Winner</p>
                    <p className="text-xs text-gray-400">Won Squad Clash Championship</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-2 bg-ff-dark/30 rounded">
                  <Target className="text-ff-red h-6 w-6" />
                  <div>
                    <p className="font-semibold">Sharp Shooter</p>
                    <p className="text-xs text-gray-400">Achieved 15+ kills in a match</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-2 bg-ff-dark/30 rounded">
                  <Medal className="text-ff-blue h-6 w-6" />
                  <div>
                    <p className="font-semibold">Top 100 Player</p>
                    <p className="text-xs text-gray-400">Reached global rank #247</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="tournaments">
          <Card className="gaming-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <History className="text-ff-orange h-5 w-5" />
                <span>Tournament History</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {userRegistrations.length === 0 ? (
                <div className="text-center py-12 text-gray-400">
                  <Trophy className="h-16 w-16 mx-auto mb-4 opacity-50" />
                  <p>No tournament history yet</p>
                  <p className="text-sm">Join your first tournament to see your history here</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {userRegistrations.slice(0, 10).map((registration) => (
                    <div key={registration.id} className="flex items-center justify-between p-4 bg-ff-dark/30 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-ff-blue to-ff-orange rounded-lg flex items-center justify-center">
                          <Trophy className="text-white h-6 w-6" />
                        </div>
                        <div>
                          <p className="font-semibold">Tournament #{registration.tournamentId}</p>
                          <p className="text-sm text-gray-400">
                            Registered on {new Date(registration.registeredAt).toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <Badge className={`${
                          registration.paymentStatus === 'completed' ? 'bg-ff-success text-black' :
                          registration.paymentStatus === 'pending' ? 'bg-ff-orange text-white' :
                          'bg-ff-red text-white'
                        }`}>
                          {registration.paymentStatus.toUpperCase()}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Achievement Cards */}
            <Card className="gaming-card">
              <CardContent className="p-6 text-center">
                <Trophy className="text-ff-gold h-12 w-12 mx-auto mb-4" />
                <h3 className="font-bold mb-2">Tournament Winner</h3>
                <p className="text-sm text-gray-400 mb-4">Win your first tournament</p>
                <Badge className="bg-ff-success text-black">UNLOCKED</Badge>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardContent className="p-6 text-center">
                <Target className="text-ff-red h-12 w-12 mx-auto mb-4" />
                <h3 className="font-bold mb-2">Sharp Shooter</h3>
                <p className="text-sm text-gray-400 mb-4">Get 15+ kills in a single match</p>
                <Badge className="bg-ff-success text-black">UNLOCKED</Badge>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardContent className="p-6 text-center">
                <Medal className="text-gray-400 h-12 w-12 mx-auto mb-4" />
                <h3 className="font-bold mb-2">Veteran Player</h3>
                <p className="text-sm text-gray-400 mb-4">Play 50 tournaments</p>
                <Badge variant="outline" className="border-gray-400 text-gray-400">LOCKED</Badge>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardContent className="p-6 text-center">
                <DollarSign className="text-ff-gold h-12 w-12 mx-auto mb-4" />
                <h3 className="font-bold mb-2">Money Maker</h3>
                <p className="text-sm text-gray-400 mb-4">Earn ₹10,000 in prizes</p>
                <Badge className="bg-ff-success text-black">UNLOCKED</Badge>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardContent className="p-6 text-center">
                <Users className="text-ff-blue h-12 w-12 mx-auto mb-4" />
                <h3 className="font-bold mb-2">Team Player</h3>
                <p className="text-sm text-gray-400 mb-4">Create and manage a team</p>
                <Badge variant="outline" className="border-gray-400 text-gray-400">LOCKED</Badge>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardContent className="p-6 text-center">
                <Award className="text-purple-500 h-12 w-12 mx-auto mb-4" />
                <h3 className="font-bold mb-2">Legend</h3>
                <p className="text-sm text-gray-400 mb-4">Reach top 10 global ranking</p>
                <Badge variant="outline" className="border-gray-400 text-gray-400">LOCKED</Badge>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="statistics">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="gaming-card">
              <CardHeader>
                <CardTitle>Gameplay Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Matches Played:</span>
                  <span className="font-bold">{userRegistrations.length}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Kills:</span>
                  <span className="font-bold text-ff-red">{user.totalKills}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Wins:</span>
                  <span className="font-bold text-ff-success">{user.totalWins}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Kill/Death Ratio:</span>
                  <span className="font-bold">{(user.totalKills / Math.max(userRegistrations.length - user.totalWins, 1)).toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Average Placement:</span>
                  <span className="font-bold">5.2</span>
                </div>
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardHeader>
                <CardTitle>Financial Statistics</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Earnings:</span>
                  <span className="font-bold text-ff-gold">₹{user.totalEarnings}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Tournament Fees Paid:</span>
                  <span className="font-bold">₹2,100</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Net Profit:</span>
                  <span className="font-bold text-ff-success">₹{(parseFloat(user.totalEarnings) - 2100).toFixed(0)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Current Coins:</span>
                  <span className="font-bold text-ff-gold">{user.coins?.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Biggest Win:</span>
                  <span className="font-bold text-ff-gold">₹1,500</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
