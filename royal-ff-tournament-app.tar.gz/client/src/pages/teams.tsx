import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertTeamSchema, Team, User } from "@shared/schema";
import { DEMO_USER } from "@/lib/constants";
import { 
  Users, 
  Plus, 
  Crown, 
  UserPlus, 
  UserMinus, 
  Edit,
  Trash2,
  Shield,
  Target,
  Trophy
} from "lucide-react";
import { z } from "zod";

const createTeamSchema = insertTeamSchema.extend({
  logoUrl: z.string().optional(),
});

type CreateTeamForm = z.infer<typeof createTeamSchema>;

export default function Teams() {
  const { toast } = useToast();
  const [selectedTeam, setSelectedTeam] = useState<Team | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [inviteUserId, setInviteUserId] = useState("");

  const { data: teams = [], isLoading } = useQuery<Team[]>({
    queryKey: [`/api/users/${DEMO_USER.id}/teams`],
  });

  const { data: teamMembers = [] } = useQuery<User[]>({
    queryKey: [`/api/teams/${selectedTeam?.id}/members`],
    enabled: !!selectedTeam,
  });

  const form = useForm<CreateTeamForm>({
    resolver: zodResolver(createTeamSchema),
    defaultValues: {
      name: "",
      logoUrl: "",
      captainId: DEMO_USER.id,
      maxMembers: 4,
    },
  });

  const createTeamMutation = useMutation({
    mutationFn: async (data: CreateTeamForm) => {
      await apiRequest('POST', '/api/teams', data);
    },
    onSuccess: () => {
      toast({
        title: "Team Created!",
        description: "Your team has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/users/${DEMO_USER.id}/teams`] });
      setIsCreateOpen(false);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Failed to Create Team",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addMemberMutation = useMutation({
    mutationFn: async ({ teamId, userId }: { teamId: number; userId: number }) => {
      await apiRequest('POST', `/api/teams/${teamId}/members`, { userId });
    },
    onSuccess: () => {
      toast({
        title: "Member Added!",
        description: "Player has been added to the team",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${selectedTeam?.id}/members`] });
      setInviteUserId("");
    },
    onError: (error) => {
      toast({
        title: "Failed to Add Member",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const removeMemberMutation = useMutation({
    mutationFn: async ({ teamId, userId }: { teamId: number; userId: number }) => {
      await apiRequest('DELETE', `/api/teams/${teamId}/members/${userId}`);
    },
    onSuccess: () => {
      toast({
        title: "Member Removed",
        description: "Player has been removed from the team",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/teams/${selectedTeam?.id}/members`] });
    },
    onError: (error) => {
      toast({
        title: "Failed to Remove Member",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onCreateTeam = (data: CreateTeamForm) => {
    createTeamMutation.mutate(data);
  };

  const handleAddMember = () => {
    if (selectedTeam && inviteUserId) {
      addMemberMutation.mutate({
        teamId: selectedTeam.id,
        userId: parseInt(inviteUserId)
      });
    }
  };

  const handleRemoveMember = (userId: number) => {
    if (selectedTeam) {
      removeMemberMutation.mutate({
        teamId: selectedTeam.id,
        userId
      });
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Users className="text-ff-blue mr-2" />
            My Teams
          </h1>
          <p className="text-gray-400">Manage your Free Fire teams and members</p>
        </div>
        
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="btn-primary">
              <Plus className="mr-2 h-4 w-4" />
              Create Team
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-ff-card border-ff-orange/30">
            <DialogHeader>
              <DialogTitle className="flex items-center space-x-2">
                <Users className="text-ff-blue h-5 w-5" />
                <span>Create New Team</span>
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={form.handleSubmit(onCreateTeam)} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="teamName">Team Name *</Label>
                <Input
                  id="teamName"
                  placeholder="e.g., Elite Squad"
                  className="input-gaming"
                  {...form.register('name')}
                />
                {form.formState.errors.name && (
                  <p className="text-red-500 text-sm">{form.formState.errors.name.message}</p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="logoUrl">Team Logo URL (Optional)</Label>
                <Input
                  id="logoUrl"
                  placeholder="https://example.com/logo.png"
                  className="input-gaming"
                  {...form.register('logoUrl')}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maxMembers">Max Members</Label>
                <Input
                  id="maxMembers"
                  type="number"
                  min="2"
                  max="6"
                  className="input-gaming"
                  {...form.register('maxMembers', { valueAsNumber: true })}
                />
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setIsCreateOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="btn-success"
                  disabled={createTeamMutation.isPending}
                >
                  {createTeamMutation.isPending ? 'Creating...' : 'Create Team'}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(3)].map((_, i) => (
            <Card key={i} className="gaming-card animate-pulse">
              <CardContent className="p-6">
                <div className="h-6 bg-ff-dark rounded mb-4" />
                <div className="h-4 bg-ff-dark rounded mb-2" />
                <div className="h-4 bg-ff-dark rounded w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Teams Grid */}
      {!isLoading && teams.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {teams.map((team) => (
            <Card 
              key={team.id} 
              className={`gaming-card hover:scale-105 transition-transform cursor-pointer ${
                selectedTeam?.id === team.id ? 'ring-2 ring-ff-orange' : ''
              }`}
              onClick={() => setSelectedTeam(team)}
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-12 h-12 bg-gradient-to-r from-ff-blue to-ff-orange rounded-lg flex items-center justify-center">
                      {team.logoUrl ? (
                        <img src={team.logoUrl} alt={team.name} className="w-full h-full object-cover rounded-lg" />
                      ) : (
                        <Users className="text-white h-6 w-6" />
                      )}
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{team.name}</h3>
                      <div className="flex items-center space-x-1">
                        <Users className="h-3 w-3 text-gray-400" />
                        <span className="text-sm text-gray-400">
                          {team.currentMembers}/{team.maxMembers} members
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  {team.captainId === DEMO_USER.id && (
                    <Badge className="bg-ff-gold text-black">
                      <Crown className="h-3 w-3 mr-1" />
                      Captain
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">
                    Created {new Date(team.createdAt).toLocaleDateString()}
                  </span>
                  <div className="flex space-x-1">
                    <Button size="sm" variant="ghost" className="text-ff-blue hover:text-ff-orange">
                      <Edit className="h-4 w-4" />
                    </Button>
                    {team.captainId === DEMO_USER.id && (
                      <Button size="sm" variant="ghost" className="text-ff-red hover:text-red-400">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Empty State */}
      {!isLoading && teams.length === 0 && (
        <Card className="gaming-card">
          <CardContent className="p-12 text-center">
            <Users className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl font-bold mb-2">No Teams Yet</h3>
            <p className="text-gray-400 mb-6">Create your first team to start competing in squad tournaments</p>
            <Button onClick={() => setIsCreateOpen(true)} className="btn-primary">
              <Plus className="mr-2 h-4 w-4" />
              Create Your First Team
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Team Details Sidebar */}
      {selectedTeam && (
        <Card className="gaming-card">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-gradient-to-r from-ff-blue to-ff-orange rounded-lg flex items-center justify-center">
                  {selectedTeam.logoUrl ? (
                    <img src={selectedTeam.logoUrl} alt={selectedTeam.name} className="w-full h-full object-cover rounded-lg" />
                  ) : (
                    <Users className="text-white h-6 w-6" />
                  )}
                </div>
                <div>
                  <h2 className="text-xl font-bold">{selectedTeam.name}</h2>
                  <p className="text-sm text-gray-400">Team Members</p>
                </div>
              </div>
              
              {selectedTeam.captainId === DEMO_USER.id && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button size="sm" className="btn-secondary">
                      <UserPlus className="mr-2 h-4 w-4" />
                      Invite Player
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="bg-ff-card border-ff-orange/30">
                    <DialogHeader>
                      <DialogTitle>Invite Player to Team</DialogTitle>
                    </DialogHeader>
                    
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="inviteUserId">Player ID</Label>
                        <Input
                          id="inviteUserId"
                          placeholder="Enter player ID"
                          className="input-gaming"
                          value={inviteUserId}
                          onChange={(e) => setInviteUserId(e.target.value)}
                        />
                      </div>
                      
                      <div className="flex justify-end space-x-2">
                        <Button variant="outline">Cancel</Button>
                        <Button 
                          onClick={handleAddMember}
                          className="btn-success"
                          disabled={!inviteUserId || addMemberMutation.isPending}
                        >
                          {addMemberMutation.isPending ? 'Inviting...' : 'Send Invite'}
                        </Button>
                      </div>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {teamMembers.map((member) => (
                <div key={member.id} className="flex items-center justify-between p-3 bg-ff-dark/30 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-r from-ff-orange to-ff-red rounded-full flex items-center justify-center">
                      <span className="text-sm font-bold">
                        {member.firstName?.[0] || member.username[0]}
                        {member.lastName?.[0] || member.username[1] || ''}
                      </span>
                    </div>
                    
                    <div>
                      <div className="flex items-center space-x-2">
                        <p className="font-semibold">
                          {member.firstName && member.lastName 
                            ? `${member.firstName} ${member.lastName}` 
                            : member.username
                          }
                        </p>
                        {member.id === selectedTeam.captainId && (
                          <Badge className="bg-ff-gold text-black text-xs">
                            <Crown className="h-3 w-3 mr-1" />
                            Captain
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-gray-400">UID: {member.gameUid || 'Not set'}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-2 text-sm">
                      <Target className="text-ff-red h-4 w-4" />
                      <span>{member.totalKills}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm">
                      <Trophy className="text-ff-gold h-4 w-4" />
                      <span>{member.totalWins}</span>
                    </div>
                    
                    {selectedTeam.captainId === DEMO_USER.id && member.id !== DEMO_USER.id && (
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="text-ff-red hover:text-red-400"
                        onClick={() => handleRemoveMember(member.id)}
                        disabled={removeMemberMutation.isPending}
                      >
                        <UserMinus className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
              
              {teamMembers.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <Shield className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>No members found</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
