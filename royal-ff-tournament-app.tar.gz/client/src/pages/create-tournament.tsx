import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { insertTournamentSchema } from "@shared/schema";
import { DEMO_USER } from "@/lib/constants";
import { useLocation } from "wouter";
import { 
  Trophy, 
  Calendar, 
  Users, 
  DollarSign,
  ArrowLeft,
  Settings,
  Target
} from "lucide-react";
import { Link } from "wouter";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { z } from "zod";

const createTournamentSchema = insertTournamentSchema.extend({
  startDate: z.string().min(1, "Start date is required"),
  startTime: z.string().min(1, "Start time is required"),
});

type CreateTournamentForm = z.infer<typeof createTournamentSchema>;

export default function CreateTournament() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);

  const form = useForm<CreateTournamentForm>({
    resolver: zodResolver(createTournamentSchema),
    defaultValues: {
      name: "",
      description: "",
      entryFee: "0",
      prizePool: "0",
      maxPlayers: 64,
      tournamentType: "squad",
      gameMode: "br",
      bracketType: "knockout",
      createdBy: DEMO_USER.id,
      startDate: "",
      startTime: "",
    },
  });

  const createMutation = useMutation({
    mutationFn: async (data: CreateTournamentForm) => {
      const { startDate, startTime, ...tournamentData } = data;
      const startDateTime = new Date(`${startDate}T${startTime}`);
      
      await apiRequest('POST', '/api/tournaments', {
        ...tournamentData,
        startTime: startDateTime.toISOString(),
      });
    },
    onSuccess: () => {
      toast({
        title: "Tournament Created!",
        description: "Your tournament has been created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tournaments'] });
      setLocation('/tournaments');
    },
    onError: (error) => {
      toast({
        title: "Failed to Create Tournament",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CreateTournamentForm) => {
    createMutation.mutate(data);
  };

  const nextStep = () => {
    setCurrentStep(prev => Math.min(prev + 1, 3));
  };

  const prevStep = () => {
    setCurrentStep(prev => Math.max(prev - 1, 1));
  };

  const calculatePrizePool = () => {
    const entryFee = parseFloat(form.watch('entryFee') || '0');
    const maxPlayers = form.watch('maxPlayers') || 0;
    const suggestedPrize = entryFee * maxPlayers * 0.8; // 80% of total collection
    form.setValue('prizePool', suggestedPrize.toString());
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Link href="/tournaments">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold flex items-center">
              <Trophy className="text-ff-gold mr-2" />
              Create Tournament
            </h1>
            <p className="text-gray-400">Set up your Free Fire tournament</p>
          </div>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center mb-8">
        <div className="flex items-center space-x-4">
          {[1, 2, 3].map((step) => (
            <div key={step} className="flex items-center">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                step <= currentStep ? 'bg-ff-orange text-white' : 'bg-ff-card text-gray-400'
              }`}>
                {step}
              </div>
              {step < 3 && (
                <div className={`w-16 h-1 mx-2 ${
                  step < currentStep ? 'bg-ff-orange' : 'bg-ff-card'
                }`} />
              )}
            </div>
          ))}
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Step 1: Basic Information */}
        {currentStep === 1 && (
          <Card className="gaming-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="text-ff-orange h-5 w-5" />
                <span>Basic Information</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="name">Tournament Name *</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Squad Clash Championship"
                    className="input-gaming"
                    {...form.register('name')}
                  />
                  {form.formState.errors.name && (
                    <p className="text-red-500 text-sm">{form.formState.errors.name.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxPlayers">Max Players *</Label>
                  <Select
                    value={form.watch('maxPlayers')?.toString()}
                    onValueChange={(value) => form.setValue('maxPlayers', parseInt(value))}
                  >
                    <SelectTrigger className="input-gaming">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-ff-card border-ff-orange/30">
                      <SelectItem value="16">16 Players</SelectItem>
                      <SelectItem value="32">32 Players</SelectItem>
                      <SelectItem value="64">64 Players</SelectItem>
                      <SelectItem value="100">100 Players</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe your tournament rules, format, and any special instructions..."
                  rows={4}
                  className="input-gaming resize-none"
                  {...form.register('description')}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="tournamentType">Tournament Type *</Label>
                  <Select
                    value={form.watch('tournamentType')}
                    onValueChange={(value) => form.setValue('tournamentType', value as any)}
                  >
                    <SelectTrigger className="input-gaming">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-ff-card border-ff-orange/30">
                      <SelectItem value="solo">Solo</SelectItem>
                      <SelectItem value="duo">Duo</SelectItem>
                      <SelectItem value="squad">Squad</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="gameMode">Game Mode *</Label>
                  <Select
                    value={form.watch('gameMode')}
                    onValueChange={(value) => form.setValue('gameMode', value as any)}
                  >
                    <SelectTrigger className="input-gaming">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-ff-card border-ff-orange/30">
                      <SelectItem value="br">Battle Royale</SelectItem>
                      <SelectItem value="clash_squad">Clash Squad</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="button" onClick={nextStep} className="btn-primary">
                  Next Step
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Schedule & Settings */}
        {currentStep === 2 && (
          <Card className="gaming-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="text-ff-blue h-5 w-5" />
                <span>Schedule & Settings</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="startDate">Start Date *</Label>
                  <Input
                    id="startDate"
                    type="date"
                    min={new Date().toISOString().split('T')[0]}
                    className="input-gaming"
                    {...form.register('startDate')}
                  />
                  {form.formState.errors.startDate && (
                    <p className="text-red-500 text-sm">{form.formState.errors.startDate.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="startTime">Start Time *</Label>
                  <Input
                    id="startTime"
                    type="time"
                    className="input-gaming"
                    {...form.register('startTime')}
                  />
                  {form.formState.errors.startTime && (
                    <p className="text-red-500 text-sm">{form.formState.errors.startTime.message}</p>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="bracketType">Bracket Type *</Label>
                <Select
                  value={form.watch('bracketType')}
                  onValueChange={(value) => form.setValue('bracketType', value as any)}
                >
                  <SelectTrigger className="input-gaming">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-ff-card border-ff-orange/30">
                    <SelectItem value="knockout">Knockout (Single Elimination)</SelectItem>
                    <SelectItem value="round_robin">Round Robin</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="bg-ff-dark/50 p-4 rounded-lg">
                <h3 className="font-semibold mb-2 flex items-center">
                  <Settings className="mr-2 h-4 w-4 text-ff-orange" />
                  Tournament Settings
                </h3>
                <div className="space-y-2 text-sm text-gray-300">
                  <p>• Room ID and password will be generated automatically</p>
                  <p>• Registration will close 10 minutes before start time</p>
                  <p>• Bracket will be generated after registration closes</p>
                  <p>• Results must be submitted by participants</p>
                </div>
              </div>

              <div className="flex justify-between">
                <Button type="button" onClick={prevStep} variant="outline" className="border-ff-orange text-ff-orange">
                  Previous
                </Button>
                <Button type="button" onClick={nextStep} className="btn-primary">
                  Next Step
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Prize & Payment */}
        {currentStep === 3 && (
          <Card className="gaming-card">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <DollarSign className="text-ff-gold h-5 w-5" />
                <span>Prize & Payment</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="entryFee">Entry Fee (₹) *</Label>
                  <Input
                    id="entryFee"
                    type="number"
                    min="0"
                    step="1"
                    placeholder="0 for free tournament"
                    className="input-gaming"
                    {...form.register('entryFee')}
                    onChange={(e) => {
                      form.register('entryFee').onChange(e);
                      // Auto-calculate prize pool after entry fee changes
                      setTimeout(calculatePrizePool, 100);
                    }}
                  />
                  {form.formState.errors.entryFee && (
                    <p className="text-red-500 text-sm">{form.formState.errors.entryFee.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="prizePool">Prize Pool (₹) *</Label>
                    <Button 
                      type="button" 
                      size="sm" 
                      variant="ghost" 
                      onClick={calculatePrizePool}
                      className="text-ff-blue hover:text-ff-orange"
                    >
                      Auto Calculate
                    </Button>
                  </div>
                  <Input
                    id="prizePool"
                    type="number"
                    min="0"
                    step="1"
                    className="input-gaming"
                    {...form.register('prizePool')}
                  />
                  {form.formState.errors.prizePool && (
                    <p className="text-red-500 text-sm">{form.formState.errors.prizePool.message}</p>
                  )}
                </div>
              </div>

              {/* Prize Breakdown Preview */}
              {parseFloat(form.watch('prizePool') || '0') > 0 && (
                <Card className="bg-ff-dark/30 border border-ff-gold/30">
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center space-x-2">
                      <Target className="text-ff-gold h-5 w-5" />
                      <span>Prize Distribution Preview</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="flex items-center space-x-2">
                          <span className="w-6 h-6 bg-ff-gold rounded-full flex items-center justify-center text-black text-xs font-bold">1</span>
                          <span>First Place</span>
                        </span>
                        <span className="font-bold text-ff-gold">
                          ₹{(parseFloat(form.watch('prizePool') || '0') * 0.5).toFixed(0)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center space-x-2">
                          <span className="w-6 h-6 bg-gray-400 rounded-full flex items-center justify-center text-black text-xs font-bold">2</span>
                          <span>Second Place</span>
                        </span>
                        <span className="font-bold text-gray-400">
                          ₹{(parseFloat(form.watch('prizePool') || '0') * 0.3).toFixed(0)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="flex items-center space-x-2">
                          <span className="w-6 h-6 bg-orange-600 rounded-full flex items-center justify-center text-white text-xs font-bold">3</span>
                          <span>Third Place</span>
                        </span>
                        <span className="font-bold text-orange-600">
                          ₹{(parseFloat(form.watch('prizePool') || '0') * 0.2).toFixed(0)}
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Tournament Summary */}
              <Card className="bg-ff-dark/30 border border-ff-blue/30">
                <CardHeader>
                  <CardTitle className="text-lg">Tournament Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Name:</span>
                        <span className="font-semibold">{form.watch('name') || 'Not set'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Type:</span>
                        <span className="font-semibold">{form.watch('tournamentType')?.toUpperCase()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Mode:</span>
                        <span className="font-semibold">{form.watch('gameMode')?.toUpperCase()}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Players:</span>
                        <span className="font-semibold">{form.watch('maxPlayers')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Entry Fee:</span>
                        <span className="font-semibold">₹{form.watch('entryFee')}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Prize Pool:</span>
                        <span className="font-semibold text-ff-gold">₹{form.watch('prizePool')}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="flex justify-between">
                <Button type="button" onClick={prevStep} variant="outline" className="border-ff-orange text-ff-orange">
                  Previous
                </Button>
                <Button 
                  type="submit" 
                  className="btn-success"
                  disabled={createMutation.isPending}
                >
                  {createMutation.isPending ? 'Creating...' : 'Create Tournament'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </form>
    </div>
  );
}
