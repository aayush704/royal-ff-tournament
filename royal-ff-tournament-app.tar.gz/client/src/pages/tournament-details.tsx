import { useState } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Tournament, Match, LeaderboardEntry } from "@shared/schema";
import { DEMO_USER } from "@/lib/constants";
import CountdownTimer from "@/components/countdown-timer";
import BracketView from "@/components/bracket-view";
import Leaderboard from "@/components/leaderboard";
import { 
  Trophy, 
  Users, 
  Clock, 
  DollarSign, 
  MapPin, 
  Calendar,
  Target,
  Medal,
  ArrowLeft,
  Share2,
  Copy
} from "lucide-react";
import { Link } from "wouter";

export default function TournamentDetails() {
  const { id } = useParams();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");

  const { data: tournament, isLoading } = useQuery<Tournament>({
    queryKey: [`/api/tournaments/${id}`],
  });

  const { data: matches = [] } = useQuery<Match[]>({
    queryKey: [`/api/tournaments/${id}/matches`],
    enabled: !!tournament,
  });

  const { data: leaderboard = [] } = useQuery<LeaderboardEntry[]>({
    queryKey: [`/api/tournaments/${id}/leaderboard`],
    enabled: !!tournament,
  });

  const registerMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('POST', `/api/tournaments/${id}/register`, {
        userId: DEMO_USER.id,
        paymentStatus: tournament?.entryFee === '0' ? 'completed' : 'pending'
      });
    },
    onSuccess: () => {
      toast({
        title: "Registration Successful!",
        description: "You have been registered for the tournament",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/tournaments/${id}`] });
    },
    onError: (error) => {
      toast({
        title: "Registration Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const copyRoomDetails = () => {
    if (tournament?.roomId) {
      const details = `Room ID: ${tournament.roomId}\nPassword: ${tournament.roomPassword || 'N/A'}`;
      navigator.clipboard.writeText(details);
      toast({
        title: "Copied!",
        description: "Room details copied to clipboard",
      });
    }
  };

  const shareTournament = () => {
    const url = window.location.href;
    navigator.clipboard.writeText(url);
    toast({
      title: "Link Copied!",
      description: "Tournament link copied to clipboard",
    });
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card className="gaming-card animate-pulse">
          <CardContent className="p-8">
            <div className="h-8 bg-ff-dark rounded mb-4" />
            <div className="h-4 bg-ff-dark rounded mb-2" />
            <div className="h-4 bg-ff-dark rounded w-1/2" />
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!tournament) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card className="gaming-card">
          <CardContent className="p-8 text-center">
            <Trophy className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-bold mb-2">Tournament Not Found</h2>
            <p className="text-gray-400 mb-4">The tournament you're looking for doesn't exist</p>
            <Link href="/tournaments">
              <Button className="btn-primary">Back to Tournaments</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'live':
        return 'status-live';
      case 'upcoming':
        return 'status-upcoming';
      case 'completed':
        return 'status-completed';
      default:
        return 'bg-gray-500';
    }
  };

  const canRegister = tournament.status === 'upcoming' && 
                     tournament.currentPlayers < tournament.maxPlayers;

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <Link href="/tournaments">
          <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Tournaments
          </Button>
        </Link>
        
        <Button onClick={shareTournament} variant="outline" size="sm" className="border-ff-orange text-ff-orange">
          <Share2 className="mr-2 h-4 w-4" />
          Share
        </Button>
      </div>

      {/* Tournament Header */}
      <Card className="gaming-card">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row justify-between items-start gap-6">
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-3">
                <Badge className={`${getStatusColor(tournament.status)} text-xs font-bold`}>
                  {tournament.status.toUpperCase()}
                </Badge>
                <Badge variant="outline" className="border-ff-blue text-ff-blue">
                  {tournament.tournamentType.toUpperCase()}
                </Badge>
                <Badge variant="outline" className="border-ff-orange text-ff-orange">
                  {tournament.gameMode.toUpperCase()}
                </Badge>
              </div>
              
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{tournament.name}</h1>
              <p className="text-gray-300 mb-4">{tournament.description}</p>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="flex items-center space-x-2">
                  <DollarSign className="text-ff-gold h-5 w-5" />
                  <div>
                    <p className="text-xs text-gray-400">Entry Fee</p>
                    <p className="font-bold">₹{tournament.entryFee}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Trophy className="text-ff-gold h-5 w-5" />
                  <div>
                    <p className="text-xs text-gray-400">Prize Pool</p>
                    <p className="font-bold text-ff-gold">₹{tournament.prizePool}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Users className="text-ff-blue h-5 w-5" />
                  <div>
                    <p className="text-xs text-gray-400">Players</p>
                    <p className="font-bold">{tournament.currentPlayers}/{tournament.maxPlayers}</p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Calendar className="text-ff-orange h-5 w-5" />
                  <div>
                    <p className="text-xs text-gray-400">Start Time</p>
                    <p className="font-bold text-sm">
                      {new Date(tournament.startTime).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col space-y-3">
              {tournament.status === 'upcoming' && (
                <CountdownTimer 
                  targetDate={new Date(tournament.startTime)}
                  className="justify-center bg-ff-dark/50 px-4 py-2 rounded-lg"
                />
              )}
              
              {canRegister && (
                <Button 
                  className="btn-success"
                  onClick={() => registerMutation.mutate()}
                  disabled={registerMutation.isPending}
                >
                  {registerMutation.isPending ? 'Registering...' : 
                   tournament.entryFee === '0' ? 'Join Free' : 'Register Now'}
                </Button>
              )}
              
              {tournament.status === 'live' && tournament.roomId && (
                <div className="bg-ff-dark/50 p-4 rounded-lg">
                  <p className="text-xs text-gray-400 mb-1">Room Details</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-mono font-bold text-ff-orange">ID: {tournament.roomId}</p>
                      {tournament.roomPassword && (
                        <p className="font-mono font-bold text-ff-blue">Pass: {tournament.roomPassword}</p>
                      )}
                    </div>
                    <Button size="sm" variant="ghost" onClick={copyRoomDetails}>
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-ff-card border border-ff-orange/30">
          <TabsTrigger value="overview" className="data-[state=active]:bg-ff-orange">
            Overview
          </TabsTrigger>
          <TabsTrigger value="bracket" className="data-[state=active]:bg-ff-orange">
            Bracket
          </TabsTrigger>
          <TabsTrigger value="leaderboard" className="data-[state=active]:bg-ff-orange">
            Leaderboard
          </TabsTrigger>
          <TabsTrigger value="rules" className="data-[state=active]:bg-ff-orange">
            Rules
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Tournament Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="gaming-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MapPin className="text-ff-orange h-5 w-5" />
                  <span>Tournament Details</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-400">Type:</span>
                  <span className="font-semibold">{tournament.tournamentType.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Game Mode:</span>
                  <span className="font-semibold">{tournament.gameMode.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Bracket Type:</span>
                  <span className="font-semibold">{tournament.bracketType.toUpperCase()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Start Time:</span>
                  <span className="font-semibold">
                    {new Date(tournament.startTime).toLocaleString()}
                  </span>
                </div>
                {tournament.endTime && (
                  <div className="flex justify-between">
                    <span className="text-gray-400">End Time:</span>
                    <span className="font-semibold">
                      {new Date(tournament.endTime).toLocaleString()}
                    </span>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="gaming-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="text-ff-red h-5 w-5" />
                  <span>Prize Distribution</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Medal className="text-ff-gold h-5 w-5" />
                    <span>1st Place</span>
                  </div>
                  <span className="font-bold text-ff-gold">₹{(parseFloat(tournament.prizePool) * 0.5).toFixed(0)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Medal className="text-gray-400 h-5 w-5" />
                    <span>2nd Place</span>
                  </div>
                  <span className="font-bold text-gray-400">₹{(parseFloat(tournament.prizePool) * 0.3).toFixed(0)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-2">
                    <Medal className="text-orange-600 h-5 w-5" />
                    <span>3rd Place</span>
                  </div>
                  <span className="font-bold text-orange-600">₹{(parseFloat(tournament.prizePool) * 0.2).toFixed(0)}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="bracket">
          <BracketView 
            matches={matches} 
            tournamentId={tournament.id}
            onUpdateResult={(matchId, winnerId) => {
              console.log('Update match result:', matchId, winnerId);
            }}
          />
        </TabsContent>

        <TabsContent value="leaderboard">
          <Leaderboard 
            players={leaderboard} 
            title={`${tournament.name} Leaderboard`}
            showPoints={true}
          />
        </TabsContent>

        <TabsContent value="rules">
          <Card className="gaming-card">
            <CardHeader>
              <CardTitle>Tournament Rules</CardTitle>
            </CardHeader>
            <CardContent className="prose prose-invert max-w-none">
              <div className="space-y-4 text-gray-300">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">General Rules</h3>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>All players must register before the tournament start time</li>
                    <li>Entry fee must be paid for paid tournaments</li>
                    <li>Players must join the room with the provided ID and password</li>
                    <li>Screenshots of results must be submitted for verification</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Gameplay Rules</h3>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>No hacking, cheating, or third-party tools allowed</li>
                    <li>Team killing is strictly prohibited</li>
                    <li>Players must follow Fair Play guidelines</li>
                    <li>Any suspicious activity will result in disqualification</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Scoring System</h3>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>Position Points: 1st - 10pts, 2nd - 6pts, 3rd - 5pts, 4th+ - 1pt</li>
                    <li>Kill Points: 1 point per kill</li>
                    <li>Final ranking based on total points across all matches</li>
                  </ul>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Prize Distribution</h3>
                  <ul className="space-y-1 list-disc list-inside">
                    <li>Prizes will be distributed within 24 hours of tournament completion</li>
                    <li>Winners must provide valid payment details</li>
                    <li>Tax deductions may apply as per regulations</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
