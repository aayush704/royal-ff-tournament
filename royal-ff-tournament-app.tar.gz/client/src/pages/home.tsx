import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { DEMO_USER } from "@/lib/constants";
import { useWebSocket } from "@/hooks/useWebSocket";
import TournamentCard from "@/components/tournament-card";
import Leaderboard from "@/components/leaderboard";
import { Tournament, User } from "@shared/schema";
import { Link } from "wouter";
import { 
  Trophy, 
  Target, 
  Medal, 
  DollarSign, 
  Users, 
  CreditCard, 
  Crown,
  Bell,
  Plus,
  Flame
} from "lucide-react";

export default function Home() {
  const { isConnected } = useWebSocket();

  const { data: tournaments = [], isLoading: tournamentsLoading } = useQuery<Tournament[]>({
    queryKey: ['/api/tournaments?status=live'],
  });

  const { data: upcomingTournaments = [] } = useQuery<Tournament[]>({
    queryKey: ['/api/tournaments?status=upcoming'],
  });

  const { data: topPlayers = [], isLoading: playersLoading } = useQuery<User[]>({
    queryKey: ['/api/leaderboard/global'],
  });

  const allTournaments = [...tournaments, ...upcomingTournaments].slice(0, 6);

  return (
    <div className="container mx-auto px-4 py-6 space-y-8">
      {/* Hero Section */}
      <Card className="gaming-card">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h2 className="text-2xl md:text-3xl font-bold mb-2">
                Welcome to <span style={{ color: 'var(--ff-blue)' }}>Royal FF Tournament</span>
              </h2>
              <p className="text-gray-300 mb-4">Join tournaments, compete with players, and win amazing prizes!</p>
              <div className="flex items-center space-x-2 text-sm">
                <div 
                  className="w-2 h-2 rounded-full" 
                  style={{ backgroundColor: isConnected ? 'var(--ff-success)' : 'var(--ff-red)' }}
                />
                <span className="text-gray-400">
                  {isConnected ? 'Connected' : 'Connecting...'} • Real-time updates
                </span>
              </div>
            </div>
            
            <div className="w-full md:w-48 h-32 rounded-lg overflow-hidden">
              <img 
                src="https://images.unsplash.com/photo-1542751371-adc38448a05e?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=300" 
                alt="Gaming tournament" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
          
          {/* Stats Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
            <div className="stats-card">
              <Trophy className="text-2xl mb-2 mx-auto" style={{ color: 'var(--ff-gold)' }} />
              <p className="text-sm text-gray-400">Tournaments Won</p>
              <p className="text-xl font-bold">{DEMO_USER.totalWins}</p>
            </div>
            <div className="stats-card">
              <Target className="text-2xl mb-2 mx-auto" style={{ color: 'var(--ff-red)' }} />
              <p className="text-sm text-gray-400">Total Kills</p>
              <p className="text-xl font-bold">{DEMO_USER.totalKills}</p>
            </div>
            <div className="stats-card">
              <Medal className="text-2xl mb-2 mx-auto" style={{ color: 'var(--ff-blue)' }} />
              <p className="text-sm text-gray-400">Global Rank</p>
              <p className="text-xl font-bold">#247</p>
            </div>
            <div className="stats-card">
              <DollarSign className="text-2xl mb-2 mx-auto" style={{ color: 'var(--ff-success)' }} />
              <p className="text-sm text-gray-400">Earnings</p>
              <p className="text-xl font-bold">₹{DEMO_USER.totalEarnings}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Live & Upcoming Tournaments */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center">
            <Crown className="mr-2" style={{ color: 'var(--ff-blue)' }} />
            Active Tournaments
          </h3>
          <Link href="/create-tournament">
            <Button className="btn-primary">
              <Plus className="mr-2 h-4 w-4" />
              Create Tournament
            </Button>
          </Link>
        </div>
        
        {tournamentsLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(3)].map((_, i) => (
              <Card key={i} className="gaming-card animate-pulse">
                <CardContent className="p-6">
                  <div className="h-4 rounded mb-4" style={{ backgroundColor: 'var(--ff-dark)' }} />
                  <div className="h-6 rounded mb-2" style={{ backgroundColor: 'var(--ff-dark)' }} />
                  <div className="h-4 rounded mb-4" style={{ backgroundColor: 'var(--ff-dark)' }} />
                  <div className="h-10 rounded" style={{ backgroundColor: 'var(--ff-dark)' }} />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : allTournaments.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allTournaments.map((tournament) => (
              <TournamentCard 
                key={tournament.id} 
                tournament={tournament}
                onRegister={(id) => console.log('Register for tournament:', id)}
              />
            ))}
          </div>
        ) : (
          <Card className="gaming-card">
            <CardContent className="p-8 text-center">
              <Crown className="h-12 w-12 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-400 mb-4">No active tournaments at the moment</p>
              <Link href="/create-tournament">
                <Button className="btn-primary">Create First Tournament</Button>
              </Link>
            </CardContent>
          </Card>
        )}
        
        {allTournaments.length > 0 && (
          <div className="text-center mt-6">
            <Link href="/tournaments">
              <Button variant="outline" className="hover:text-white" style={{ borderColor: 'var(--ff-blue)', color: 'var(--ff-blue)' }}>
                View All Tournaments
              </Button>
            </Link>
          </div>
        )}
      </section>

      {/* Quick Actions */}
      <section>
        <h3 className="text-xl font-bold mb-6 flex items-center">
          <Crown className="mr-2" style={{ color: 'var(--ff-blue)' }} />
          Quick Actions
        </h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Link href="/teams">
            <Card className="gaming-card hover:scale-105 transition-transform cursor-pointer">
              <CardContent className="p-6 text-center">
                <Users className="text-3xl mb-3 mx-auto" style={{ color: 'var(--ff-blue)' }} />
                <p className="font-semibold">Create Team</p>
                <p className="text-xs text-gray-400 mt-1">Form your squad</p>
              </CardContent>
            </Card>
          </Link>
          
          <Card className="gaming-card hover:scale-105 transition-transform cursor-pointer">
            <CardContent className="p-6 text-center">
              <CreditCard className="text-3xl mb-3 mx-auto" style={{ color: 'var(--ff-blue)' }} />
              <p className="font-semibold">Add Funds</p>
              <p className="text-xs text-gray-400 mt-1">Top up wallet</p>
            </CardContent>
          </Card>
          
          <Link href="/tournaments">
            <Card className="gaming-card hover:scale-105 transition-transform cursor-pointer">
              <CardContent className="p-6 text-center">
                <Trophy className="text-3xl mb-3 mx-auto" style={{ color: 'var(--ff-success)' }} />
                <p className="font-semibold">Brackets</p>
                <p className="text-xs text-gray-400 mt-1">View matches</p>
              </CardContent>
            </Card>
          </Link>
          
          <Link href="/profile">
            <Card className="gaming-card hover:scale-105 transition-transform cursor-pointer">
              <CardContent className="p-6 text-center">
                <Bell className="text-3xl mb-3 mx-auto" style={{ color: 'var(--ff-blue)' }} />
                <p className="font-semibold">Notifications</p>
                <p className="text-xs text-gray-400 mt-1">View updates</p>
              </CardContent>
            </Card>
          </Link>
        </div>
      </section>

      {/* Top Players */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-xl font-bold flex items-center">
            <Trophy className="mr-2" style={{ color: 'var(--ff-gold)' }} />
            Top Players
          </h3>
          <Link href="/leaderboard">
            <Button variant="outline" className="hover:text-black" style={{ borderColor: 'var(--ff-gold)', color: 'var(--ff-gold)' }}>
              View Full Leaderboard
            </Button>
          </Link>
        </div>
        
        {playersLoading ? (
          <Card className="gaming-card animate-pulse">
            <CardContent className="p-6">
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="flex items-center space-x-4">
                    <div className="w-10 h-10 rounded-full" style={{ backgroundColor: 'var(--ff-dark)' }} />
                    <div className="flex-1">
                      <div className="h-4 rounded mb-2" style={{ backgroundColor: 'var(--ff-dark)' }} />
                      <div className="h-3 rounded w-1/2" style={{ backgroundColor: 'var(--ff-dark)' }} />
                    </div>
                    <div className="w-16 h-4 rounded" style={{ backgroundColor: 'var(--ff-dark)' }} />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Leaderboard players={topPlayers.slice(0, 5)} />
        )}
      </section>

      {/* Recent Activity */}
      <section>
        <h3 className="text-xl font-bold mb-6 flex items-center">
          <Bell className="mr-2" style={{ color: 'var(--ff-blue)' }} />
          Recent Activity
        </h3>
        
        <Card className="gaming-card">
          <CardContent className="p-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between py-3 border-b border-gray-700/50">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center mr-4" style={{ backgroundColor: 'rgba(0, 255, 0, 0.2)' }}>
                    <Trophy className="h-5 w-5" style={{ color: 'var(--ff-success)' }} />
                  </div>
                  <div>
                    <p className="font-semibold">Tournament Registration</p>
                    <p className="text-sm text-gray-400">You registered for "Solo King Tournament"</p>
                  </div>
                </div>
                <span className="text-xs text-gray-500">2h ago</span>
              </div>
              
              <div className="flex items-center justify-between py-3 border-b border-gray-700/50">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-ff-blue/20 rounded-full flex items-center justify-center mr-4">
                    <Users className="text-ff-blue h-5 w-5" />
                  </div>
                  <div>
                    <p className="font-semibold">Team Invitation</p>
                    <p className="text-sm text-gray-400">ProGamer_X invited you to join "Elite Squad"</p>
                  </div>
                </div>
                <span className="text-xs text-gray-500">5h ago</span>
              </div>
              
              <div className="flex items-center justify-between py-3">
                <div className="flex items-center">
                  <div className="w-10 h-10 rounded-full flex items-center justify-center mr-4" style={{ backgroundColor: 'rgba(66, 153, 255, 0.2)' }}>
                    <Flame className="h-5 w-5" style={{ color: 'var(--ff-blue)' }} />
                  </div>
                  <div>
                    <p className="font-semibold">New Tournament Alert</p>
                    <p className="text-sm text-gray-400">"Mega Championship" starting in 30 minutes</p>
                  </div>
                </div>
                <span className="text-xs text-gray-500">1d ago</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
