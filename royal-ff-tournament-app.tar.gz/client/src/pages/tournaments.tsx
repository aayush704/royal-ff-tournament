import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { Tournament } from "@shared/schema";
import TournamentCard from "@/components/tournament-card";
import { Link } from "wouter";
import { 
  Search, 
  Filter, 
  Plus, 
  Trophy, 
  Clock,
  Users,
  Target
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Tournaments() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");

  const { data: tournaments = [], isLoading } = useQuery<Tournament[]>({
    queryKey: ['/api/tournaments'],
  });

  const filteredTournaments = tournaments.filter(tournament => {
    const matchesSearch = tournament.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tournament.description?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || tournament.status === statusFilter;
    const matchesType = typeFilter === "all" || tournament.tournamentType === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const groupedTournaments = {
    live: filteredTournaments.filter(t => t.status === 'live'),
    upcoming: filteredTournaments.filter(t => t.status === 'upcoming'),
    completed: filteredTournaments.filter(t => t.status === 'completed'),
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Trophy className="text-ff-gold mr-2" />
            Tournaments
          </h1>
          <p className="text-gray-400">Compete in Free Fire tournaments and win prizes</p>
        </div>
        
        <Link href="/create-tournament">
          <Button className="btn-primary">
            <Plus className="mr-2 h-4 w-4" />
            Create Tournament
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <Card className="gaming-card">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search tournaments..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="input-gaming pl-10"
                />
              </div>
            </div>
            
            <div className="flex gap-2">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-32 input-gaming">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent className="bg-ff-card border-ff-orange/30">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="live">Live</SelectItem>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
              
              <Select value={typeFilter} onValueChange={setTypeFilter}>
                <SelectTrigger className="w-32 input-gaming">
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent className="bg-ff-card border-ff-orange/30">
                  <SelectItem value="all">All Types</SelectItem>
                  <SelectItem value="solo">Solo</SelectItem>
                  <SelectItem value="duo">Duo</SelectItem>
                  <SelectItem value="squad">Squad</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tournament Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <Trophy className="text-ff-success h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Live Now</p>
            <p className="text-2xl font-bold text-ff-success">{groupedTournaments.live.length}</p>
          </CardContent>
        </Card>
        
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <Clock className="text-ff-orange h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Starting Soon</p>
            <p className="text-2xl font-bold text-ff-orange">{groupedTournaments.upcoming.length}</p>
          </CardContent>
        </Card>
        
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <Users className="text-ff-blue h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Total Players</p>
            <p className="text-2xl font-bold text-ff-blue">
              {tournaments.reduce((sum, t) => sum + t.currentPlayers, 0)}
            </p>
          </CardContent>
        </Card>
        
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <Target className="text-ff-gold h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Prize Pool</p>
            <p className="text-2xl font-bold text-ff-gold">
              ₹{tournaments.reduce((sum, t) => sum + parseFloat(t.prizePool), 0).toLocaleString()}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Loading State */}
      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="gaming-card animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-ff-dark rounded mb-4" />
                <div className="h-6 bg-ff-dark rounded mb-2" />
                <div className="h-4 bg-ff-dark rounded mb-4" />
                <div className="h-10 bg-ff-dark rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Live Tournaments */}
      {!isLoading && groupedTournaments.live.length > 0 && (
        <section>
          <div className="flex items-center space-x-2 mb-4">
            <Badge className="status-live">LIVE</Badge>
            <h2 className="text-xl font-bold">Live Tournaments</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groupedTournaments.live.map((tournament) => (
              <TournamentCard 
                key={tournament.id} 
                tournament={tournament}
                onRegister={(id) => console.log('Join tournament:', id)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Upcoming Tournaments */}
      {!isLoading && groupedTournaments.upcoming.length > 0 && (
        <section>
          <div className="flex items-center space-x-2 mb-4">
            <Badge className="status-upcoming">UPCOMING</Badge>
            <h2 className="text-xl font-bold">Upcoming Tournaments</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groupedTournaments.upcoming.map((tournament) => (
              <TournamentCard 
                key={tournament.id} 
                tournament={tournament}
                onRegister={(id) => console.log('Register for tournament:', id)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Completed Tournaments */}
      {!isLoading && groupedTournaments.completed.length > 0 && (
        <section>
          <div className="flex items-center space-x-2 mb-4">
            <Badge className="status-completed">COMPLETED</Badge>
            <h2 className="text-xl font-bold">Completed Tournaments</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groupedTournaments.completed.map((tournament) => (
              <TournamentCard 
                key={tournament.id} 
                tournament={tournament}
              />
            ))}
          </div>
        </section>
      )}

      {/* Empty State */}
      {!isLoading && filteredTournaments.length === 0 && (
        <Card className="gaming-card">
          <CardContent className="p-12 text-center">
            <Trophy className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-xl font-bold mb-2">No tournaments found</h3>
            <p className="text-gray-400 mb-6">
              {searchTerm || statusFilter !== "all" || typeFilter !== "all" 
                ? "Try adjusting your search or filters" 
                : "Be the first to create a tournament!"
              }
            </p>
            <Link href="/create-tournament">
              <Button className="btn-primary">
                <Plus className="mr-2 h-4 w-4" />
                Create Tournament
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
