import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Tournament, User, TournamentRegistration } from "@shared/schema";
import { DEMO_USER } from "@/lib/constants";
import TournamentCard from "@/components/tournament-card";
import Leaderboard from "@/components/leaderboard";
import { 
  Shield, 
  Trophy, 
  Users, 
  DollarSign,
  Settings,
  AlertTriangle,
  CheckCircle,
  XCircle,
  Edit,
  Trash2,
  Eye,
  Play,
  Pause,
  BarChart3,
  UserCheck,
  Ban
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export default function Admin() {
  const { toast } = useToast();
  const [selectedTournament, setSelectedTournament] = useState<Tournament | null>(null);
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: tournaments = [], isLoading: tournamentsLoading } = useQuery<Tournament[]>({
    queryKey: ['/api/tournaments'],
  });

  const { data: allUsers = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ['/api/leaderboard/global'],
  });

  const { data: tournamentRegistrations = [] } = useQuery<TournamentRegistration[]>({
    queryKey: [`/api/tournaments/${selectedTournament?.id}/registrations`],
    enabled: !!selectedTournament,
  });

  const updateTournamentMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Tournament> }) => {
      await apiRequest('PUT', `/api/tournaments/${id}`, updates);
    },
    onSuccess: () => {
      toast({
        title: "Tournament Updated",
        description: "Tournament has been updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tournaments'] });
    },
    onError: (error) => {
      toast({
        title: "Update Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const deleteTournamentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/tournaments/${id}`);
    },
    onSuccess: () => {
      toast({
        title: "Tournament Deleted",
        description: "Tournament has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/tournaments'] });
    },
    onError: (error) => {
      toast({
        title: "Delete Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const filteredTournaments = tournaments.filter(tournament => 
    statusFilter === "all" || tournament.status === statusFilter
  );

  const tournamentStats = {
    total: tournaments.length,
    live: tournaments.filter(t => t.status === 'live').length,
    upcoming: tournaments.filter(t => t.status === 'upcoming').length,
    completed: tournaments.filter(t => t.status === 'completed').length,
  };

  const totalRevenue = tournaments.reduce((sum, t) => 
    sum + (parseFloat(t.entryFee) * t.currentPlayers), 0
  );

  const totalPrizePools = tournaments.reduce((sum, t) => 
    sum + parseFloat(t.prizePool), 0
  );

  if (!DEMO_USER.isAdmin) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card className="gaming-card">
          <CardContent className="p-12 text-center">
            <Shield className="h-16 w-16 mx-auto mb-4 text-gray-400" />
            <h2 className="text-xl font-bold mb-2">Access Denied</h2>
            <p className="text-gray-400">You don't have permission to access the admin panel</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center">
            <Shield className="text-ff-orange mr-2" />
            Admin Dashboard
          </h1>
          <p className="text-gray-400">Manage tournaments, users, and platform settings</p>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <Trophy className="text-ff-gold h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Total Tournaments</p>
            <p className="text-2xl font-bold">{tournamentStats.total}</p>
          </CardContent>
        </Card>
        
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <Users className="text-ff-blue h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Total Users</p>
            <p className="text-2xl font-bold">{allUsers.length}</p>
          </CardContent>
        </Card>
        
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <DollarSign className="text-ff-success h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Total Revenue</p>
            <p className="text-2xl font-bold">₹{totalRevenue.toLocaleString()}</p>
          </CardContent>
        </Card>
        
        <Card className="gaming-card">
          <CardContent className="p-4 text-center">
            <BarChart3 className="text-ff-orange h-8 w-8 mx-auto mb-2" />
            <p className="text-sm text-gray-400">Prize Pools</p>
            <p className="text-2xl font-bold">₹{totalPrizePools.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs defaultValue="tournaments">
        <TabsList className="bg-ff-card border border-ff-orange/30">
          <TabsTrigger value="tournaments" className="data-[state=active]:bg-ff-orange">
            Tournaments
          </TabsTrigger>
          <TabsTrigger value="users" className="data-[state=active]:bg-ff-orange">
            Users
          </TabsTrigger>
          <TabsTrigger value="analytics" className="data-[state=active]:bg-ff-orange">
            Analytics
          </TabsTrigger>
          <TabsTrigger value="settings" className="data-[state=active]:bg-ff-orange">
            Settings
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tournaments" className="space-y-6">
          {/* Tournament Management */}
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">Tournament Management</h2>
            <div className="flex items-center space-x-4">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger className="w-40 input-gaming">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-ff-card border-ff-orange/30">
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="live">Live</SelectItem>
                  <SelectItem value="upcoming">Upcoming</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {tournamentsLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="gaming-card animate-pulse">
                  <CardContent className="p-6">
                    <div className="h-6 bg-ff-dark rounded mb-4" />
                    <div className="h-4 bg-ff-dark rounded mb-2" />
                    <div className="h-4 bg-ff-dark rounded w-1/2" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {/* Tournament Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTournaments.map((tournament) => (
                  <Card key={tournament.id} className="gaming-card">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <Badge className={`${
                          tournament.status === 'live' ? 'status-live' :
                          tournament.status === 'upcoming' ? 'status-upcoming' :
                          'status-completed'
                        }`}>
                          {tournament.status.toUpperCase()}
                        </Badge>
                        <div className="flex space-x-1">
                          <Button 
                            size="sm" 
                            variant="ghost"
                            onClick={() => setSelectedTournament(tournament)}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="text-ff-blue">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button 
                            size="sm" 
                            variant="ghost" 
                            className="text-ff-red"
                            onClick={() => deleteTournamentMutation.mutate(tournament.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      
                      <h3 className="font-bold text-lg mb-2">{tournament.name}</h3>
                      <p className="text-sm text-gray-400 mb-4 line-clamp-2">
                        {tournament.description}
                      </p>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-400">Players:</span>
                          <span>{tournament.currentPlayers}/{tournament.maxPlayers}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Entry Fee:</span>
                          <span>₹{tournament.entryFee}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Prize Pool:</span>
                          <span className="text-ff-gold font-bold">₹{tournament.prizePool}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-400">Revenue:</span>
                          <span className="text-ff-success font-bold">
                            ₹{(parseFloat(tournament.entryFee) * tournament.currentPlayers).toLocaleString()}
                          </span>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex space-x-2">
                        {tournament.status === 'upcoming' && (
                          <Button 
                            size="sm" 
                            className="btn-success flex-1"
                            onClick={() => updateTournamentMutation.mutate({
                              id: tournament.id,
                              updates: { status: 'live' }
                            })}
                          >
                            <Play className="mr-1 h-4 w-4" />
                            Start
                          </Button>
                        )}
                        
                        {tournament.status === 'live' && (
                          <Button 
                            size="sm" 
                            className="btn-secondary flex-1"
                            onClick={() => updateTournamentMutation.mutate({
                              id: tournament.id,
                              updates: { status: 'completed' }
                            })}
                          >
                            <Pause className="mr-1 h-4 w-4" />
                            End
                          </Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Tournament Details Modal */}
          {selectedTournament && (
            <Dialog open={!!selectedTournament} onOpenChange={() => setSelectedTournament(null)}>
              <DialogContent className="bg-ff-card border-ff-orange/30 max-w-4xl">
                <DialogHeader>
                  <DialogTitle className="flex items-center space-x-2">
                    <Trophy className="text-ff-gold h-5 w-5" />
                    <span>{selectedTournament.name}</span>
                  </DialogTitle>
                </DialogHeader>
                
                <div className="space-y-6">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div className="text-center">
                      <p className="text-sm text-gray-400">Status</p>
                      <Badge className={`${
                        selectedTournament.status === 'live' ? 'status-live' :
                        selectedTournament.status === 'upcoming' ? 'status-upcoming' :
                        'status-completed'
                      }`}>
                        {selectedTournament.status.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-400">Players</p>
                      <p className="font-bold">{selectedTournament.currentPlayers}/{selectedTournament.maxPlayers}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-400">Entry Fee</p>
                      <p className="font-bold">₹{selectedTournament.entryFee}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-gray-400">Prize Pool</p>
                      <p className="font-bold text-ff-gold">₹{selectedTournament.prizePool}</p>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="font-semibold mb-2">Registered Players</h3>
                    <div className="max-h-60 overflow-y-auto space-y-2">
                      {tournamentRegistrations.map((reg) => (
                        <div key={reg.id} className="flex items-center justify-between p-2 bg-ff-dark/30 rounded">
                          <span>Player #{reg.userId}</span>
                          <Badge className={`${
                            reg.paymentStatus === 'completed' ? 'bg-ff-success text-black' :
                            reg.paymentStatus === 'pending' ? 'bg-ff-orange text-white' :
                            'bg-ff-red text-white'
                          }`}>
                            {reg.paymentStatus.toUpperCase()}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </TabsContent>

        <TabsContent value="users">
          <div className="space-y-6">
            <h2 className="text-xl font-bold">User Management</h2>
            
            {usersLoading ? (
              <Card className="gaming-card animate-pulse">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {[...Array(10)].map((_, i) => (
                      <div key={i} className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-ff-dark rounded-full" />
                        <div className="flex-1">
                          <div className="h-4 bg-ff-dark rounded mb-2" />
                          <div className="h-3 bg-ff-dark rounded w-1/2" />
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ) : (
              <Card className="gaming-card">
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {allUsers.map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-4 bg-ff-dark/30 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-gradient-to-r from-ff-orange to-ff-red rounded-full flex items-center justify-center">
                            <span className="font-bold text-sm">
                              {user.firstName?.[0] || user.username[0]}
                              {user.lastName?.[0] || user.username[1] || ''}
                            </span>
                          </div>
                          <div>
                            <p className="font-semibold">
                              {user.firstName && user.lastName 
                                ? `${user.firstName} ${user.lastName}` 
                                : user.username
                              }
                            </p>
                            <p className="text-sm text-gray-400">
                              UID: {user.gameUid || 'Not set'} • {user.totalKills} kills • {user.totalWins} wins
                            </p>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          {user.isAdmin && (
                            <Badge className="bg-ff-gold text-black">ADMIN</Badge>
                          )}
                          <Button size="sm" variant="ghost" className="text-ff-blue">
                            <UserCheck className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="ghost" className="text-ff-red">
                            <Ban className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Platform Analytics</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="gaming-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BarChart3 className="text-ff-blue h-5 w-5" />
                    <span>Revenue Analysis</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Revenue:</span>
                    <span className="font-bold text-ff-success">₹{totalRevenue.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Prize Pools:</span>
                    <span className="font-bold text-ff-gold">₹{totalPrizePools.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Platform Profit:</span>
                    <span className="font-bold text-ff-orange">₹{(totalRevenue - totalPrizePools).toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Profit Margin:</span>
                    <span className="font-bold">
                      {totalRevenue > 0 ? ((totalRevenue - totalPrizePools) / totalRevenue * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                </CardContent>
              </Card>

              <Card className="gaming-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Trophy className="text-ff-gold h-5 w-5" />
                    <span>Tournament Stats</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Live Tournaments:</span>
                    <span className="font-bold text-ff-success">{tournamentStats.live}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Upcoming:</span>
                    <span className="font-bold text-ff-orange">{tournamentStats.upcoming}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Completed:</span>
                    <span className="font-bold text-gray-400">{tournamentStats.completed}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Avg Players per Tournament:</span>
                    <span className="font-bold">
                      {tournaments.length > 0 ? 
                        Math.round(tournaments.reduce((sum, t) => sum + t.currentPlayers, 0) / tournaments.length) : 
                        0
                      }
                    </span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="settings">
          <div className="space-y-6">
            <h2 className="text-xl font-bold">Platform Settings</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="gaming-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Settings className="text-ff-orange h-5 w-5" />
                    <span>General Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-semibold">Platform Commission (%)</label>
                    <Input className="input-gaming" defaultValue="20" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold">Minimum Entry Fee (₹)</label>
                    <Input className="input-gaming" defaultValue="50" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-semibold">Maximum Players per Tournament</label>
                    <Input className="input-gaming" defaultValue="100" />
                  </div>
                  <Button className="btn-success w-full">Save Settings</Button>
                </CardContent>
              </Card>

              <Card className="gaming-card">
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="text-ff-red h-5 w-5" />
                    <span>System Actions</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button className="w-full btn-secondary">
                    Generate Room IDs for All Live Tournaments
                  </Button>
                  <Button className="w-full btn-secondary">
                    Send Notifications to All Users
                  </Button>
                  <Button className="w-full btn-secondary">
                    Export Tournament Data
                  </Button>
                  <Button variant="outline" className="w-full border-ff-red text-ff-red">
                    <AlertTriangle className="mr-2 h-4 w-4" />
                    Emergency: Cancel All Tournaments
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
